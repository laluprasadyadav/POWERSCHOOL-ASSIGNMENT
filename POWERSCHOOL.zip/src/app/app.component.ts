import { Component } from '@angular/core';
import { SearchService } from './search.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'powerschool';
  word:any;
  result: any;
  constructor(private searchService:SearchService
    
  ) {
    
  }

  getWords(){
    this.searchService.getWords(this.word).subscribe(res=>{
      this.result = res;
    })
  }

}
