import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpRequest, HttpParams, HttpHandler } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SearchService extends HttpClient {

  private Url = 'http://scool/string';
  constructor(handler: HttpHandler,http:HttpHandler) {
    super(handler);
  }

  getWords(string): Observable<any> {
    return this.http.request('GET', this.Url + '?string='+string);
  }
}
