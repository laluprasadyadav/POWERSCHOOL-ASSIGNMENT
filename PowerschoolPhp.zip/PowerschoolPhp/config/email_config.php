<?php

// email configurations
define( 'EMAIL_USERNAME', 'srikanth.tirupathi@yum.com' );
define( 'EMAIL_PASSWORD', 'pizzahut@123' );
define( 'EMAIL_HOST', 'smtp.gmail.com' );
define( 'PG_SECRET_KEY', 'sk_test_RbJF7cpvRTozSueGMUB0QKHj00lKyibkOu' );
define( 'PG_PUBLISHABLE_KEY', 'pk_test_xstfo8eqlz84on8jVvimIt0H00wEAskcGn' );
// sendgrid Configuration 

define ('SENDGRID_API_KEY', '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');
?>
