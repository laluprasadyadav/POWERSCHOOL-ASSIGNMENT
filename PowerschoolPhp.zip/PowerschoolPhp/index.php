<?php

use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Formatter\LineFormatter;
require 'src/routes/search.php';
include 'constants.php';

require 'src/db_handler/searchData.php';

include_once('geoPHP-1.2/geoPHP.inc');


$app = new \Slim\App();
$app->get( '/string/{string}', 'getSearchSuggessions' );
$app->run();
