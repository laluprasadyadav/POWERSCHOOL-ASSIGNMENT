<?php

//Common Constants ........................

define( 'DEAL_TYPE', 9 );
define( 'MENUITEM_TYPE', 8 );
define( 'MODIFIER_TYPE', 7 );
define( 'MODIFIERGROUP_TYPE', 6 );
define( 'CATEGORY_TYPE', 5 );
define( 'USER_TYPE', 11 );
define( 'COUNTRY', 165 );
define( 'ORDER_NEW', "New");
define( 'ORDER_ACCEPTED', "Accepted");
define( 'ORDER_DECLINED', "Declined");
define( 'CUSTOMER_MAIL', "support@gmail.com");

define( 'SIZE_TYPE', 15 );

?>
