<?php
function getSearchSuggessions( $request, $response )
 {

    $searchDb = new SearchHandler();
        $query = $request->getQueryParams();
        $data = $searchDb->getWords($query['string']);
        if($data){
            return json_encode($data);
        } else {
            $data = "No words found";
            return json_encode($data);
        }
        

}
?>