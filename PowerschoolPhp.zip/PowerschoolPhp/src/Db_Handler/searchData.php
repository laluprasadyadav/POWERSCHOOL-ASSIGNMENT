<?php

class SearchHandler {
    private $conn;

    function __construct() {
        error_reporting( E_ALL );
        ini_set( 'display_errors', 1 );
        require_once dirname( __FILE__ ) . '/dbconnect.php';
        // opening db connection
        $db  =  new DbConnect();

        $this->conn  =  $db->connect();

    }

    function getWords( $string )
 {
        $query = "SELECT * FROM Words where name like '$string%'";

        $stmt = $this->conn->prepare( $query );

        
        $result  =  $stmt->execute();


        // Check for successful insertion
        if ( $result ) {

            return $result;

        } else {

            return null;
        }
        $this->conn->commit();
        $stmt->close();
    }

    
}
?>