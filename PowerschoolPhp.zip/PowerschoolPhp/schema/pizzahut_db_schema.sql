-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2019 at 02:08 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


-- --------------------------------------------------------

--
-- Table structure for table `access_types`
--

CREATE TABLE `access_types` (
  `id` int(11)  NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11)  NULL,
  `name` varchar(255)  NULL,
  `posid` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_size_mapping`
--

CREATE TABLE `category_size_mapping` (
  `id` int(11)  NULL,
  `category_id` int(11)  NULL,
  `size_id` int(11) DEFAULT NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `channels`
--

CREATE TABLE `channels` (
  `id` int(11)  NULL,
  `name` varchar(255)  NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11)  NULL,
  `name` varchar(255)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_by`, `created_date`, `modified_by`, `modified_date`, `active`) VALUES
(1, 'Afghanistan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(2, 'Albania', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(3, 'Algeria', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(4, 'American Samoa', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(5, 'Andorra', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(6, 'Angola', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(7, 'Anguilla', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(8, 'Antarctica', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(9, 'Antigua And Barbuda', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(10, 'Argentina', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(11, 'Armenia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(12, 'Aruba', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(13, 'Australia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(14, 'Austria', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(15, 'Azerbaijan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(16, 'Bahamas The', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(17, 'Bahrain', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(18, 'Bangladesh', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(19, 'Barbados', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(20, 'Belarus', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(21, 'Belgium', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(22, 'Belize', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(23, 'Benin', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(24, 'Bermuda', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(25, 'Bhutan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(26, 'Bolivia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(27, 'Bosnia and Herzegovina', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(28, 'Botswana', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(29, 'Bouvet Island', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(30, 'Brazil', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(31, 'British Indian Ocean Territory', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(32, 'Brunei', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(33, 'Bulgaria', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(34, 'Burkina Faso', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(35, 'Burundi', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(36, 'Cambodia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(37, 'Cameroon', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(38, 'Canada', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(39, 'Cape Verde', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(40, 'Cayman Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(41, 'Central African Republic', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(42, 'Chad', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(43, 'Chile', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(44, 'China', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(45, 'Christmas Island', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(46, 'Cocos (Keeling) Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(47, 'Colombia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(48, 'Comoros', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(49, 'Republic Of The Congo', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(50, 'Democratic Republic Of The Congo', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(51, 'Cook Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(52, 'Costa Rica', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(53, 'Cote D\'Ivoire (Ivory Coast)', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(54, 'Croatia (Hrvatska)', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(55, 'Cuba', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(56, 'Cyprus', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(57, 'Czech Republic', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(58, 'Denmark', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(59, 'Djibouti', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(60, 'Dominica', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(61, 'Dominican Republic', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(62, 'East Timor', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(63, 'Ecuador', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(64, 'Egypt', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(65, 'El Salvador', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(66, 'Equatorial Guinea', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(67, 'Eritrea', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(68, 'Estonia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(69, 'Ethiopia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(70, 'External Territories of Australia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(71, 'Falkland Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(72, 'Faroe Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(73, 'Fiji Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(74, 'Finland', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(75, 'France', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(76, 'French Guiana', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(77, 'French Polynesia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(78, 'French Southern Territories', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(79, 'Gabon', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(80, 'Gambia The', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(81, 'Georgia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(82, 'Germany', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(83, 'Ghana', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(84, 'Gibraltar', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(85, 'Greece', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(86, 'Greenland', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(87, 'Grenada', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(88, 'Guadeloupe', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(89, 'Guam', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(90, 'Guatemala', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(91, 'Guernsey and Alderney', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(92, 'Guinea', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(93, 'Guinea-Bissau', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(94, 'Guyana', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(95, 'Haiti', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(96, 'Heard and McDonald Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(97, 'Honduras', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(98, 'Hong Kong S.A.R.', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(99, 'Hungary', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(100, 'Iceland', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(101, 'India', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(102, 'Indonesia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(103, 'Iran', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(104, 'Iraq', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(105, 'Ireland', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(106, 'Israel', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(107, 'Italy', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(108, 'Jamaica', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(109, 'Japan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(110, 'Jersey', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(111, 'Jordan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(112, 'Kazakhstan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(113, 'Kenya', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(114, 'Kiribati', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(115, 'Korea North', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(116, 'Korea South', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(117, 'Kuwait', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(118, 'Kyrgyzstan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(119, 'Laos', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(120, 'Latvia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(121, 'Lebanon', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(122, 'Lesotho', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(123, 'Liberia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(124, 'Libya', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(125, 'Liechtenstein', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(126, 'Lithuania', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(127, 'Luxembourg', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(128, 'Macau S.A.R.', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(129, 'Macedonia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(130, 'Madagascar', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(131, 'Malawi', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(132, 'Malaysia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(133, 'Maldives', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(134, 'Mali', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(135, 'Malta', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(136, 'Man (Isle of)', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(137, 'Marshall Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(138, 'Martinique', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(139, 'Mauritania', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(140, 'Mauritius', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(141, 'Mayotte', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(142, 'Mexico', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(143, 'Micronesia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(144, 'Moldova', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(145, 'Monaco', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(146, 'Mongolia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(147, 'Montserrat', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(148, 'Morocco', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(149, 'Mozambique', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(150, 'Myanmar', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(151, 'Namibia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(152, 'Nauru', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(153, 'Nepal', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(154, 'Netherlands Antilles', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(155, 'Netherlands The', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(156, 'New Caledonia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(157, 'New Zealand', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(158, 'Nicaragua', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(159, 'Niger', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(160, 'Nigeria', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(161, 'Niue', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(162, 'Norfolk Island', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(163, 'Northern Mariana Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(164, 'Norway', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(165, 'Oman', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(166, 'Pakistan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(167, 'Palau', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(168, 'Palestinian Territory Occupied', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(169, 'Panama', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(170, 'Papua new Guinea', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(171, 'Paraguay', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(172, 'Peru', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(173, 'Philippines', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(174, 'Pitcairn Island', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(175, 'Poland', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(176, 'Portugal', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(177, 'Puerto Rico', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(178, 'Qatar', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(179, 'Reunion', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(180, 'Romania', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(181, 'Russia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(182, 'Rwanda', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(183, 'Saint Helena', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(184, 'Saint Kitts And Nevis', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(185, 'Saint Lucia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(186, 'Saint Pierre and Miquelon', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(187, 'Saint Vincent And The Grenadines', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(188, 'Samoa', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(189, 'San Marino', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(190, 'Sao Tome and Principe', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(191, 'Saudi Arabia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(192, 'Senegal', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(193, 'Serbia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(194, 'Seychelles', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(195, 'Sierra Leone', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(196, 'Singapore', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(197, 'Slovakia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(198, 'Slovenia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(199, 'Smaller Territories of the UK', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(200, 'Solomon Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(201, 'Somalia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(202, 'South Africa', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(203, 'South Georgia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(204, 'South Sudan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(205, 'Spain', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(206, 'Sri Lanka', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(207, 'Sudan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(208, 'Suriname', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(209, 'Svalbard And Jan Mayen Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(210, 'Swaziland', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(211, 'Sweden', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(212, 'Switzerland', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(213, 'Syria', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(214, 'Taiwan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(215, 'Tajikistan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(216, 'Tanzania', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(217, 'Thailand', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(218, 'Togo', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(219, 'Tokelau', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(220, 'Tonga', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(221, 'Trinidad And Tobago', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(222, 'Tunisia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(223, 'Turkey', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(224, 'Turkmenistan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(225, 'Turks And Caicos Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(226, 'Tuvalu', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(227, 'Uganda', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(228, 'Ukraine', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(229, 'United Arab Emirates', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(230, 'United Kingdom', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(231, 'United States', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(232, 'United States Minor Outlying Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(233, 'Uruguay', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(234, 'Uzbekistan', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(235, 'Vanuatu', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(236, 'Vatican City State (Holy See)', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(237, 'Venezuela', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(238, 'Vietnam', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(239, 'Virgin Islands (British)', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(240, 'Virgin Islands (US)', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(241, 'Wallis And Futuna Islands', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(242, 'Western Sahara', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(243, 'Yemen', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(244, 'Yugoslavia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(245, 'Zambia', 0, '2019-04-26 07:24:28', 0, NULL, 0),
(246, 'Zimbabwe', 0, '2019-04-26 07:24:28', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `country_location_type_mapping`
--

CREATE TABLE `country_location_type_mapping` (
  `id` int(11)  NULL,
  `country_id` int(11)  NULL,
  `location_type_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` int(11)  NULL,
  `country` int(255)  NULL,
  `currency` varchar(255)  NULL,
  `decimal_points` int(11)  NULL,
  `decimal_separator` varchar(255)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `dealitem_saleitem_mapping`
--

CREATE TABLE `dealitem_saleitem_mapping` (
  `id` int(11)  NULL,
  `dealitem_id` int(11) DEFAULT NULL,
  `saleitem_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp(6) NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp(6) NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deals`
--

CREATE TABLE `deals` (
  `id` int(11)  NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `percentage` float DEFAULT NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `deal_category_mapping`
--

CREATE TABLE `deal_category_mapping` (
  `id` int(11)  NULL,
  `deal_id` int(11)  NULL,
  `category_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `deal_items`
--

CREATE TABLE `deal_items` (
  `id` int(11)  NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `deal_id` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp(6) NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp(6) NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `deal_modifiergroup_mapping`
--

CREATE TABLE `deal_modifiergroup_mapping` (
  `id` int(11)  NULL,
  `deal_id` int(11)  NULL,
  `modifiergroup_id` int(11) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11)  NULL,
  `type` int(11)  NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11)  NULL,
  `name` varchar(255)  NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11)  NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci  NULL,
  `type` int(255)  NULL,
  `parent` int(255) DEFAULT NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL,
  `country_id` int(11)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `location_types`
--

CREATE TABLE `location_types` (
  `id` int(11)  NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mail_server_details`
--

CREATE TABLE `mail_server_details` (
  `id` int(11)  NULL,
  `server_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passsword` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp  NULL DEFAULT NULL,
  `active` int(11)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manage_price`
--

CREATE TABLE `manage_price` (
  `id` int(11)  NULL,
  `saleitem_id` int(11)  NULL,
  `price` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modifiers`
--

CREATE TABLE `modifiers` (
  `id` int(11)  NULL,
  `name` varchar(255)  NULL,
  `modifiergroup_id` int(11)  NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modifier_category_mapping`
--

CREATE TABLE `modifier_category_mapping` (
  `id` int(11)  NULL,
  `category_id` int(11)  NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modifier_groups`
--

CREATE TABLE `modifier_groups` (
  `id` int(11)  NULL,
  `name` varchar(255) DEFAULT NULL,
  `posid` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `operating_timings`
--

CREATE TABLE `operating_timings` (
  `id` int(11)  NULL,
  `day` varchar(255)  NULL,
  `start_time` time  NULL,
  `close_time` time  NULL,
  `break_time` time  NULL,
  `reopen_time` time  NULL,
  `store_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` datetime  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11)  NULL,
  `user_id` int(11) DEFAULT NULL,
  `total_price` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `address1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `instructions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Table structure for table `order_deliveries`
--

CREATE TABLE `order_deliveries` (
  `id` int(11)  NULL,
  `order_id` int(11) DEFAULT NULL,
  `order_place_date` date DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_delivery_date` date DEFAULT NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11)  NULL,
  `order_id` int(11) DEFAULT NULL,
  `saleitem_id` int(11) DEFAULT NULL,
  `item_price` float DEFAULT NULL,
  `no_of_items` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `instructions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Table structure for table `order_modifiers`
--

CREATE TABLE `order_modifiers` (
  `id` int(11)  NULL,
  `order_item_id` int(11) DEFAULT NULL,
  `modifiergroup_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_suppliers`
--

CREATE TABLE `order_suppliers` (
  `id` int(11)  NULL,
  `order_item_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- Table structure for table `payment_options`
--

CREATE TABLE `payment_options` (
  `id` int(11)  NULL,
  `option_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` int(11) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11)  NULL,
  `name` varchar(255)  NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `role_modules`
--

CREATE TABLE `role_modules` (
  `id` int(11)  NULL,
  `role_id` int(11)  NULL,
  `type_id` int(11)  NULL,
  `accesstype_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `saleitem_channel_mapping`
--

CREATE TABLE `saleitem_channel_mapping` (
  `id` int(11)  NULL,
  `manageprice_id` int(11)  NULL,
  `channel_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` int(11) DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `saleitem_day_mapping`
--

CREATE TABLE `saleitem_day_mapping` (
  `id` int(11)  NULL,
  `manageprice_id` int(11) DEFAULT NULL,
  `days` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp(6) NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp(6) NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `saleitem_modifiergroup_mapping`
--

CREATE TABLE `saleitem_modifiergroup_mapping` (
  `id` int(11)  NULL,
  `saleitem_id` int(11) DEFAULT NULL,
  `modifiergroup_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `size_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Table structure for table `saleitem_modifier_mapping`
--

CREATE TABLE `saleitem_modifier_mapping` (
  `id` int(11)  NULL,
  `saleitem_modifiergroup_id` int(11)  NULL,
  `size_id` int(11)  NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `price` float  NULL,
  `posid` int(11)  NULL,
  `is_enabled` tinyint(1)  NULL,
  `is_default` tinyint(1)  NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Table structure for table `sale_items`
--

CREATE TABLE `sale_items` (
  `id` int(11)  NULL,
  `posid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `visible_in_store` tinyint(1) DEFAULT NULL,
  `item_in_stock` tinyint(1) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Table structure for table `setting_types`
--

CREATE TABLE `setting_types` (
  `id` int(11)  NULL,
  `key_name` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp(6) NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp(6) NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` int(11)  NULL,
  `size` varchar(255)  NULL,
  `active` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sms_settings`
--

CREATE TABLE `sms_settings` (
  `id` int(11)  NULL,
  `service_provider` varchar(255) COLLATE utf8_unicode_ci  NULL,
  `api_key` varchar(255) COLLATE utf8_unicode_ci  NULL,
  `api_secret` varchar(255) COLLATE utf8_unicode_ci  NULL,
  `phone_number` varchar(255) COLLATE utf8_unicode_ci  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL,
  `user_id` int(11)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11)  NULL,
  `name` varchar(255)  NULL,
  `country_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `country_id`, `created_by`, `created_date`, `modified_by`, `modified_date`, `active`) VALUES
(1, 'Andaman and Nicobar Islands', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2, 'Andhra Pradesh', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(3, 'Arunachal Pradesh', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(4, 'Assam', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(5, 'Bihar', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(6, 'Chandigarh', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(7, 'Chhattisgarh', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(8, 'Dadra and Nagar Haveli', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(9, 'Daman and Diu', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(10, 'Delhi', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(11, 'Goa', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(12, 'Gujarat', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(13, 'Haryana', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(14, 'Himachal Pradesh', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(15, 'Jammu and Kashmir', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(16, 'Jharkhand', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(17, 'Karnataka', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(18, 'Kenmore', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(19, 'Kerala', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(20, 'Lakshadweep', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(21, 'Madhya Pradesh', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(22, 'Maharashtra', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(23, 'Manipur', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(24, 'Meghalaya', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(25, 'Mizoram', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(26, 'Nagaland', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(27, 'Narora', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(28, 'Natwar', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(29, 'Odisha', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(30, 'Paschim Medinipur', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(31, 'Pondicherry', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(32, 'Punjab', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(33, 'Rajasthan', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(34, 'Sikkim', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(35, 'Tamil Nadu', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(36, 'Telangana', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(37, 'Tripura', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(38, 'Uttar Pradesh', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(39, 'Uttarakhand', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(40, 'Vaishali', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(41, 'West Bengal', 101, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(42, 'Badakhshan', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(43, 'Badgis', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(44, 'Baglan', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(45, 'Balkh', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(46, 'Bamiyan', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(47, 'Farah', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(48, 'Faryab', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(49, 'Gawr', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(50, 'Gazni', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(51, 'Herat', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(52, 'Hilmand', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(53, 'Jawzjan', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(54, 'Kabul', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(55, 'Kapisa', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(56, 'Khawst', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(57, 'Kunar', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(58, 'Lagman', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(59, 'Lawghar', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(60, 'Nangarhar', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(61, 'Nimruz', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(62, 'Nuristan', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(63, 'Paktika', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(64, 'Paktiya', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(65, 'Parwan', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(66, 'Qandahar', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(67, 'Qunduz', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(68, 'Samangan', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(69, 'Sar-e Pul', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(70, 'Takhar', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(71, 'Uruzgan', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(72, 'Wardag', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(73, 'Zabul', 1, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(74, 'Berat', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(75, 'Bulqize', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(76, 'Delvine', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(77, 'Devoll', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(78, 'Dibre', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(79, 'Durres', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(80, 'Elbasan', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(81, 'Fier', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(82, 'Gjirokaster', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(83, 'Gramsh', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(84, 'Has', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(85, 'Kavaje', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(86, 'Kolonje', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(87, 'Korce', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(88, 'Kruje', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(89, 'Kucove', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(90, 'Kukes', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(91, 'Kurbin', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(92, 'Lezhe', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(93, 'Librazhd', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(94, 'Lushnje', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(95, 'Mallakaster', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(96, 'Malsi e Madhe', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(97, 'Mat', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(98, 'Mirdite', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(99, 'Peqin', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(100, 'Permet', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(101, 'Pogradec', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(102, 'Puke', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(103, 'Sarande', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(104, 'Shkoder', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(105, 'Skrapar', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(106, 'Tepelene', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(107, 'Tirane', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(108, 'Tropoje', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(109, 'Vlore', 2, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(110, '\'Ayn Daflah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(111, '\'Ayn Tamushanat', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(112, 'Adrar', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(113, 'Algiers', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(114, 'Annabah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(115, 'Bashshar', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(116, 'Batnah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(117, 'Bijayah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(118, 'Biskrah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(119, 'Blidah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(120, 'Buirah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(121, 'Bumardas', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(122, 'Burj Bu Arririj', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(123, 'Ghalizan', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(124, 'Ghardayah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(125, 'Ilizi', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(126, 'Jijili', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(127, 'Jilfah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(128, 'Khanshalah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(129, 'Masilah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(130, 'Midyah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(131, 'Milah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(132, 'Muaskar', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(133, 'Mustaghanam', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(134, 'Naama', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(135, 'Oran', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(136, 'Ouargla', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(137, 'Qalmah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(138, 'Qustantinah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(139, 'Sakikdah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(140, 'Satif', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(141, 'Sayda\'', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(142, 'Sidi ban-al-\'Abbas', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(143, 'Suq Ahras', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(144, 'Tamanghasat', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(145, 'Tibazah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(146, 'Tibissah', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(147, 'Tilimsan', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(148, 'Tinduf', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(149, 'Tisamsilt', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(150, 'Tiyarat', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(151, 'Tizi Wazu', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(152, 'Umm-al-Bawaghi', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(153, 'Wahran', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(154, 'Warqla', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(155, 'Wilaya d Alger', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(156, 'Wilaya de Bejaia', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(157, 'Wilaya de Constantine', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(158, 'al-Aghwat', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(159, 'al-Bayadh', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(160, 'al-Jaza\'ir', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(161, 'al-Wad', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(162, 'ash-Shalif', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(163, 'at-Tarif', 3, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(164, 'Eastern', 4, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(165, 'Manu\'a', 4, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(166, 'Swains Island', 4, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(167, 'Western', 4, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(168, 'Andorra la Vella', 5, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(169, 'Canillo', 5, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(170, 'Encamp', 5, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(171, 'La Massana', 5, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(172, 'Les Escaldes', 5, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(173, 'Ordino', 5, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(174, 'Sant Julia de Loria', 5, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(175, 'Bengo', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(176, 'Benguela', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(177, 'Bie', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(178, 'Cabinda', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(179, 'Cunene', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(180, 'Huambo', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(181, 'Huila', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(182, 'Kuando-Kubango', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(183, 'Kwanza Norte', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(184, 'Kwanza Sul', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(185, 'Luanda', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(186, 'Lunda Norte', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(187, 'Lunda Sul', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(188, 'Malanje', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(189, 'Moxico', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(190, 'Namibe', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(191, 'Uige', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(192, 'Zaire', 6, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(193, 'Other Provinces', 7, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(194, 'Sector claimed by Argentina/Ch', 8, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(195, 'Sector claimed by Argentina/UK', 8, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(196, 'Sector claimed by Australia', 8, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(197, 'Sector claimed by France', 8, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(198, 'Sector claimed by New Zealand', 8, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(199, 'Sector claimed by Norway', 8, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(200, 'Unclaimed Sector', 8, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(201, 'Barbuda', 9, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(202, 'Saint George', 9, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(203, 'Saint John', 9, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(204, 'Saint Mary', 9, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(205, 'Saint Paul', 9, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(206, 'Saint Peter', 9, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(207, 'Saint Philip', 9, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(208, 'Buenos Aires', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(209, 'Catamarca', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(210, 'Chaco', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(211, 'Chubut', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(212, 'Cordoba', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(213, 'Corrientes', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(214, 'Distrito Federal', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(215, 'Entre Rios', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(216, 'Formosa', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(217, 'Jujuy', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(218, 'La Pampa', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(219, 'La Rioja', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(220, 'Mendoza', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(221, 'Misiones', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(222, 'Neuquen', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(223, 'Rio Negro', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(224, 'Salta', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(225, 'San Juan', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(226, 'San Luis', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(227, 'Santa Cruz', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(228, 'Santa Fe', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(229, 'Santiago del Estero', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(230, 'Tierra del Fuego', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(231, 'Tucuman', 10, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(232, 'Aragatsotn', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(233, 'Ararat', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(234, 'Armavir', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(235, 'Gegharkunik', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(236, 'Kotaik', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(237, 'Lori', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(238, 'Shirak', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(239, 'Stepanakert', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(240, 'Syunik', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(241, 'Tavush', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(242, 'Vayots Dzor', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(243, 'Yerevan', 11, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(244, 'Aruba', 12, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(245, 'Auckland', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(246, 'Australian Capital Territory', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(247, 'Balgowlah', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(248, 'Balmain', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(249, 'Bankstown', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(250, 'Baulkham Hills', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(251, 'Bonnet Bay', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(252, 'Camberwell', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(253, 'Carole Park', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(254, 'Castle Hill', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(255, 'Caulfield', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(256, 'Chatswood', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(257, 'Cheltenham', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(258, 'Cherrybrook', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(259, 'Clayton', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(260, 'Collingwood', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(261, 'Frenchs Forest', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(262, 'Hawthorn', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(263, 'Jannnali', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(264, 'Knoxfield', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(265, 'Melbourne', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(266, 'New South Wales', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(267, 'Northern Territory', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(268, 'Perth', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(269, 'Queensland', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(270, 'South Australia', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(271, 'Tasmania', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(272, 'Templestowe', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(273, 'Victoria', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(274, 'Werribee south', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(275, 'Western Australia', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(276, 'Wheeler', 13, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(277, 'Bundesland Salzburg', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(278, 'Bundesland Steiermark', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(279, 'Bundesland Tirol', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(280, 'Burgenland', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(281, 'Carinthia', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(282, 'Karnten', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(283, 'Liezen', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(284, 'Lower Austria', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(285, 'Niederosterreich', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(286, 'Oberosterreich', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(287, 'Salzburg', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(288, 'Schleswig-Holstein', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(289, 'Steiermark', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(290, 'Styria', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(291, 'Tirol', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(292, 'Upper Austria', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(293, 'Vorarlberg', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(294, 'Wien', 14, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(295, 'Abseron', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(296, 'Baki Sahari', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(297, 'Ganca', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(298, 'Ganja', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(299, 'Kalbacar', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(300, 'Lankaran', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(301, 'Mil-Qarabax', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(302, 'Mugan-Salyan', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(303, 'Nagorni-Qarabax', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(304, 'Naxcivan', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(305, 'Priaraks', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(306, 'Qazax', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(307, 'Saki', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(308, 'Sirvan', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(309, 'Xacmaz', 15, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(310, 'Abaco', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(311, 'Acklins Island', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(312, 'Andros', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(313, 'Berry Islands', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(314, 'Biminis', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(315, 'Cat Island', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(316, 'Crooked Island', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(317, 'Eleuthera', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(318, 'Exuma and Cays', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(319, 'Grand Bahama', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(320, 'Inagua Islands', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(321, 'Long Island', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(322, 'Mayaguana', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(323, 'New Providence', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(324, 'Ragged Island', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(325, 'Rum Cay', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(326, 'San Salvador', 16, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(327, '\'Isa', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(328, 'Badiyah', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(329, 'Hidd', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(330, 'Jidd Hafs', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(331, 'Mahama', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(332, 'Manama', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(333, 'Sitrah', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(334, 'al-Manamah', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(335, 'al-Muharraq', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(336, 'ar-Rifa\'a', 17, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(337, 'Bagar Hat', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(338, 'Bandarban', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(339, 'Barguna', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(340, 'Barisal', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(341, 'Bhola', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(342, 'Bogora', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(343, 'Brahman Bariya', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(344, 'Chandpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(345, 'Chattagam', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(346, 'Chittagong Division', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(347, 'Chuadanga', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(348, 'Dhaka', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(349, 'Dinajpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(350, 'Faridpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(351, 'Feni', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(352, 'Gaybanda', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(353, 'Gazipur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(354, 'Gopalganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(355, 'Habiganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(356, 'Jaipur Hat', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(357, 'Jamalpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(358, 'Jessor', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(359, 'Jhalakati', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(360, 'Jhanaydah', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(361, 'Khagrachhari', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(362, 'Khulna', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(363, 'Kishorganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(364, 'Koks Bazar', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(365, 'Komilla', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(366, 'Kurigram', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(367, 'Kushtiya', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(368, 'Lakshmipur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(369, 'Lalmanir Hat', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(370, 'Madaripur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(371, 'Magura', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(372, 'Maimansingh', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(373, 'Manikganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(374, 'Maulvi Bazar', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(375, 'Meherpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(376, 'Munshiganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(377, 'Naral', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(378, 'Narayanganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(379, 'Narsingdi', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(380, 'Nator', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(381, 'Naugaon', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(382, 'Nawabganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(383, 'Netrakona', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(384, 'Nilphamari', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(385, 'Noakhali', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(386, 'Pabna', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(387, 'Panchagarh', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(388, 'Patuakhali', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(389, 'Pirojpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(390, 'Rajbari', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(391, 'Rajshahi', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(392, 'Rangamati', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(393, 'Rangpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(394, 'Satkhira', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(395, 'Shariatpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(396, 'Sherpur', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(397, 'Silhat', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(398, 'Sirajganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(399, 'Sunamganj', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(400, 'Tangayal', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(401, 'Thakurgaon', 18, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(402, 'Christ Church', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(403, 'Saint Andrew', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(404, 'Saint George', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(405, 'Saint James', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(406, 'Saint John', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(407, 'Saint Joseph', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(408, 'Saint Lucy', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(409, 'Saint Michael', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(410, 'Saint Peter', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(411, 'Saint Philip', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(412, 'Saint Thomas', 19, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(413, 'Brest', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(414, 'Homjel\'', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(415, 'Hrodna', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(416, 'Mahiljow', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(417, 'Mahilyowskaya Voblasts', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(418, 'Minsk', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(419, 'Minskaja Voblasts\'', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(420, 'Petrik', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(421, 'Vicebsk', 20, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(422, 'Antwerpen', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(423, 'Berchem', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(424, 'Brabant', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(425, 'Brabant Wallon', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(426, 'Brussel', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(427, 'East Flanders', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(428, 'Hainaut', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(429, 'Liege', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(430, 'Limburg', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(431, 'Luxembourg', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(432, 'Namur', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(433, 'Ontario', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(434, 'Oost-Vlaanderen', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(435, 'Provincie Brabant', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(436, 'Vlaams-Brabant', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(437, 'Wallonne', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(438, 'West-Vlaanderen', 21, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(439, 'Belize', 22, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(440, 'Cayo', 22, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(441, 'Corozal', 22, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(442, 'Orange Walk', 22, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(443, 'Stann Creek', 22, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(444, 'Toledo', 22, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(445, 'Alibori', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(446, 'Atacora', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(447, 'Atlantique', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(448, 'Borgou', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(449, 'Collines', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(450, 'Couffo', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(451, 'Donga', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(452, 'Littoral', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(453, 'Mono', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(454, 'Oueme', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(455, 'Plateau', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(456, 'Zou', 23, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(457, 'Hamilton', 24, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(458, 'Saint George', 24, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(459, 'Bumthang', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(460, 'Chhukha', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(461, 'Chirang', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(462, 'Daga', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(463, 'Geylegphug', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(464, 'Ha', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(465, 'Lhuntshi', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(466, 'Mongar', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(467, 'Pemagatsel', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(468, 'Punakha', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(469, 'Rinpung', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(470, 'Samchi', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(471, 'Samdrup Jongkhar', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(472, 'Shemgang', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(473, 'Tashigang', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(474, 'Timphu', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(475, 'Tongsa', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(476, 'Wangdiphodrang', 25, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(477, 'Beni', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(478, 'Chuquisaca', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(479, 'Cochabamba', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(480, 'La Paz', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(481, 'Oruro', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(482, 'Pando', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(483, 'Potosi', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(484, 'Santa Cruz', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(485, 'Tarija', 26, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(486, 'Federacija Bosna i Hercegovina', 27, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(487, 'Republika Srpska', 27, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(488, 'Central Bobonong', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(489, 'Central Boteti', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(490, 'Central Mahalapye', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(491, 'Central Serowe-Palapye', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(492, 'Central Tutume', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(493, 'Chobe', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(494, 'Francistown', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(495, 'Gaborone', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(496, 'Ghanzi', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(497, 'Jwaneng', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(498, 'Kgalagadi North', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(499, 'Kgalagadi South', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(500, 'Kgatleng', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(501, 'Kweneng', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(502, 'Lobatse', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(503, 'Ngamiland', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(504, 'Ngwaketse', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(505, 'North East', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(506, 'Okavango', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(507, 'Orapa', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(508, 'Selibe Phikwe', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(509, 'South East', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(510, 'Sowa', 28, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(511, 'Bouvet Island', 29, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(512, 'Acre', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(513, 'Alagoas', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(514, 'Amapa', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(515, 'Amazonas', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(516, 'Bahia', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(517, 'Ceara', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(518, 'Distrito Federal', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(519, 'Espirito Santo', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(520, 'Estado de Sao Paulo', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(521, 'Goias', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(522, 'Maranhao', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(523, 'Mato Grosso', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(524, 'Mato Grosso do Sul', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(525, 'Minas Gerais', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(526, 'Para', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(527, 'Paraiba', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(528, 'Parana', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(529, 'Pernambuco', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(530, 'Piaui', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(531, 'Rio Grande do Norte', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(532, 'Rio Grande do Sul', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(533, 'Rio de Janeiro', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(534, 'Rondonia', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(535, 'Roraima', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(536, 'Santa Catarina', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(537, 'Sao Paulo', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(538, 'Sergipe', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(539, 'Tocantins', 30, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(540, 'British Indian Ocean Territory', 31, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(541, 'Belait', 32, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(542, 'Brunei-Muara', 32, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(543, 'Temburong', 32, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(544, 'Tutong', 32, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(545, 'Blagoevgrad', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(546, 'Burgas', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(547, 'Dobrich', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(548, 'Gabrovo', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(549, 'Haskovo', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(550, 'Jambol', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(551, 'Kardzhali', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(552, 'Kjustendil', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(553, 'Lovech', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(554, 'Montana', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(555, 'Oblast Sofiya-Grad', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(556, 'Pazardzhik', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(557, 'Pernik', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(558, 'Pleven', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(559, 'Plovdiv', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(560, 'Razgrad', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(561, 'Ruse', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(562, 'Shumen', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(563, 'Silistra', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(564, 'Sliven', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(565, 'Smoljan', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(566, 'Sofija grad', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(567, 'Sofijska oblast', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(568, 'Stara Zagora', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(569, 'Targovishte', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(570, 'Varna', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(571, 'Veliko Tarnovo', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(572, 'Vidin', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(573, 'Vraca', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(574, 'Yablaniza', 33, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(575, 'Bale', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(576, 'Bam', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(577, 'Bazega', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(578, 'Bougouriba', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(579, 'Boulgou', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(580, 'Boulkiemde', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(581, 'Comoe', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(582, 'Ganzourgou', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(583, 'Gnagna', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(584, 'Gourma', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(585, 'Houet', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(586, 'Ioba', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(587, 'Kadiogo', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(588, 'Kenedougou', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(589, 'Komandjari', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(590, 'Kompienga', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(591, 'Kossi', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(592, 'Kouritenga', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(593, 'Kourweogo', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(594, 'Leraba', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(595, 'Mouhoun', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(596, 'Nahouri', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(597, 'Namentenga', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(598, 'Noumbiel', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(599, 'Oubritenga', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(600, 'Oudalan', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(601, 'Passore', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(602, 'Poni', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(603, 'Sanguie', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(604, 'Sanmatenga', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(605, 'Seno', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(606, 'Sissili', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(607, 'Soum', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(608, 'Sourou', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(609, 'Tapoa', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(610, 'Tuy', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(611, 'Yatenga', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(612, 'Zondoma', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(613, 'Zoundweogo', 34, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(614, 'Bubanza', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(615, 'Bujumbura', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(616, 'Bururi', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(617, 'Cankuzo', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(618, 'Cibitoke', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(619, 'Gitega', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(620, 'Karuzi', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(621, 'Kayanza', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(622, 'Kirundo', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(623, 'Makamba', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(624, 'Muramvya', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(625, 'Muyinga', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(626, 'Ngozi', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(627, 'Rutana', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(628, 'Ruyigi', 35, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(629, 'Banteay Mean Chey', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(630, 'Bat Dambang', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(631, 'Kampong Cham', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(632, 'Kampong Chhnang', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(633, 'Kampong Spoeu', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(634, 'Kampong Thum', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(635, 'Kampot', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(636, 'Kandal', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(637, 'Kaoh Kong', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(638, 'Kracheh', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(639, 'Krong Kaeb', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(640, 'Krong Pailin', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(641, 'Krong Preah Sihanouk', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(642, 'Mondol Kiri', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(643, 'Otdar Mean Chey', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(644, 'Phnum Penh', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(645, 'Pousat', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(646, 'Preah Vihear', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(647, 'Prey Veaeng', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(648, 'Rotanak Kiri', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(649, 'Siem Reab', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(650, 'Stueng Traeng', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(651, 'Svay Rieng', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(652, 'Takaev', 36, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(653, 'Adamaoua', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(654, 'Centre', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(655, 'Est', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(656, 'Littoral', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(657, 'Nord', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(658, 'Nord Extreme', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(659, 'Nordouest', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(660, 'Ouest', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(661, 'Sud', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(662, 'Sudouest', 37, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(663, 'Alberta', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(664, 'British Columbia', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(665, 'Manitoba', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(666, 'New Brunswick', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(667, 'Newfoundland and Labrador', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(668, 'Northwest Territories', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(669, 'Nova Scotia', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(670, 'Nunavut', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(671, 'Ontario', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(672, 'Prince Edward Island', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(673, 'Quebec', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(674, 'Saskatchewan', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(675, 'Yukon', 38, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(676, 'Boavista', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(677, 'Brava', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(678, 'Fogo', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(679, 'Maio', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(680, 'Sal', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(681, 'Santo Antao', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(682, 'Sao Nicolau', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(683, 'Sao Tiago', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(684, 'Sao Vicente', 39, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(685, 'Grand Cayman', 40, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(686, 'Bamingui-Bangoran', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(687, 'Bangui', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(688, 'Basse-Kotto', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(689, 'Haut-Mbomou', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(690, 'Haute-Kotto', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(691, 'Kemo', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(692, 'Lobaye', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(693, 'Mambere-Kadei', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(694, 'Mbomou', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(695, 'Nana-Gribizi', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(696, 'Nana-Mambere', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(697, 'Ombella Mpoko', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(698, 'Ouaka', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(699, 'Ouham', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(700, 'Ouham-Pende', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(701, 'Sangha-Mbaere', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(702, 'Vakaga', 41, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(703, 'Batha', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(704, 'Biltine', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(705, 'Bourkou-Ennedi-Tibesti', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(706, 'Chari-Baguirmi', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(707, 'Guera', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(708, 'Kanem', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(709, 'Lac', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(710, 'Logone Occidental', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(711, 'Logone Oriental', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(712, 'Mayo-Kebbi', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(713, 'Moyen-Chari', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(714, 'Ouaddai', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(715, 'Salamat', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(716, 'Tandjile', 42, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(717, 'Aisen', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(718, 'Antofagasta', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(719, 'Araucania', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(720, 'Atacama', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(721, 'Bio Bio', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(722, 'Coquimbo', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(723, 'Libertador General Bernardo O\'', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(724, 'Los Lagos', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(725, 'Magellanes', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(726, 'Maule', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(727, 'Metropolitana', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(728, 'Metropolitana de Santiago', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(729, 'Tarapaca', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(730, 'Valparaiso', 43, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(731, 'Anhui', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(734, 'Aomen', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(735, 'Beijing', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(736, 'Beijing Shi', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(737, 'Chongqing', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(738, 'Fujian', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(740, 'Gansu', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(741, 'Guangdong', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(743, 'Guangxi', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(744, 'Guizhou', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(745, 'Hainan', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(746, 'Hebei', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(747, 'Heilongjiang', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(748, 'Henan', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(749, 'Hubei', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(750, 'Hunan', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(751, 'Jiangsu', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(753, 'Jiangxi', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(754, 'Jilin', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(755, 'Liaoning', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(757, 'Nei Monggol', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(758, 'Ningxia Hui', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(759, 'Qinghai', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(760, 'Shaanxi', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(761, 'Shandong', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(763, 'Shanghai', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(764, 'Shanxi', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(765, 'Sichuan', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(766, 'Tianjin', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(767, 'Xianggang', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(768, 'Xinjiang', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(769, 'Xizang', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(770, 'Yunnan', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(771, 'Zhejiang', 44, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(773, 'Christmas Island', 45, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(774, 'Cocos (Keeling) Islands', 46, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(775, 'Amazonas', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(776, 'Antioquia', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(777, 'Arauca', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(778, 'Atlantico', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(779, 'Bogota', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(780, 'Bolivar', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(781, 'Boyaca', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(782, 'Caldas', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(783, 'Caqueta', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(784, 'Casanare', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(785, 'Cauca', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(786, 'Cesar', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(787, 'Choco', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(788, 'Cordoba', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(789, 'Cundinamarca', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(790, 'Guainia', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(791, 'Guaviare', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(792, 'Huila', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(793, 'La Guajira', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(794, 'Magdalena', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(795, 'Meta', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(796, 'Narino', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(797, 'Norte de Santander', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(798, 'Putumayo', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(799, 'Quindio', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(800, 'Risaralda', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(801, 'San Andres y Providencia', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(802, 'Santander', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(803, 'Sucre', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(804, 'Tolima', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(805, 'Valle del Cauca', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(806, 'Vaupes', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(807, 'Vichada', 47, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(808, 'Mwali', 48, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(809, 'Njazidja', 48, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(810, 'Nzwani', 48, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(811, 'Bouenza', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(812, 'Brazzaville', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(813, 'Cuvette', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(814, 'Kouilou', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(815, 'Lekoumou', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(816, 'Likouala', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(817, 'Niari', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(818, 'Plateaux', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(819, 'Pool', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(820, 'Sangha', 49, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(821, 'Bandundu', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(822, 'Bas-Congo', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(823, 'Equateur', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(824, 'Haut-Congo', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(825, 'Kasai-Occidental', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(826, 'Kasai-Oriental', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(827, 'Katanga', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(828, 'Kinshasa', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(829, 'Maniema', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(830, 'Nord-Kivu', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(831, 'Sud-Kivu', 50, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(832, 'Aitutaki', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(833, 'Atiu', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(834, 'Mangaia', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(835, 'Manihiki', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(836, 'Mauke', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(837, 'Mitiaro', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(838, 'Nassau', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(839, 'Pukapuka', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(840, 'Rakahanga', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(841, 'Rarotonga', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(842, 'Tongareva', 51, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(843, 'Alajuela', 52, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(844, 'Cartago', 52, 0, '2019-04-26 07:22:55', 0, NULL, 0);
INSERT INTO `states` (`id`, `name`, `country_id`, `created_by`, `created_date`, `modified_by`, `modified_date`, `active`) VALUES
(845, 'Guanacaste', 52, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(846, 'Heredia', 52, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(847, 'Limon', 52, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(848, 'Puntarenas', 52, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(849, 'San Jose', 52, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(850, 'Abidjan', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(851, 'Agneby', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(852, 'Bafing', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(853, 'Denguele', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(854, 'Dix-huit Montagnes', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(855, 'Fromager', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(856, 'Haut-Sassandra', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(857, 'Lacs', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(858, 'Lagunes', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(859, 'Marahoue', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(860, 'Moyen-Cavally', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(861, 'Moyen-Comoe', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(862, 'N\'zi-Comoe', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(863, 'Sassandra', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(864, 'Savanes', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(865, 'Sud-Bandama', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(866, 'Sud-Comoe', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(867, 'Vallee du Bandama', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(868, 'Worodougou', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(869, 'Zanzan', 53, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(870, 'Bjelovar-Bilogora', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(871, 'Dubrovnik-Neretva', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(872, 'Grad Zagreb', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(873, 'Istra', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(874, 'Karlovac', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(875, 'Koprivnica-Krizhevci', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(876, 'Krapina-Zagorje', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(877, 'Lika-Senj', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(878, 'Medhimurje', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(879, 'Medimurska Zupanija', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(880, 'Osijek-Baranja', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(881, 'Osjecko-Baranjska Zupanija', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(882, 'Pozhega-Slavonija', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(883, 'Primorje-Gorski Kotar', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(884, 'Shibenik-Knin', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(885, 'Sisak-Moslavina', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(886, 'Slavonski Brod-Posavina', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(887, 'Split-Dalmacija', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(888, 'Varazhdin', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(889, 'Virovitica-Podravina', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(890, 'Vukovar-Srijem', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(891, 'Zadar', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(892, 'Zagreb', 54, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(893, 'Camaguey', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(894, 'Ciego de Avila', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(895, 'Cienfuegos', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(896, 'Ciudad de la Habana', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(897, 'Granma', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(898, 'Guantanamo', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(899, 'Habana', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(900, 'Holguin', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(901, 'Isla de la Juventud', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(902, 'La Habana', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(903, 'Las Tunas', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(904, 'Matanzas', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(905, 'Pinar del Rio', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(906, 'Sancti Spiritus', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(907, 'Santiago de Cuba', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(908, 'Villa Clara', 55, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(909, 'Government controlled area', 56, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(910, 'Limassol', 56, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(911, 'Nicosia District', 56, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(912, 'Paphos', 56, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(913, 'Turkish controlled area', 56, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(914, 'Central Bohemian', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(915, 'Frycovice', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(916, 'Jihocesky Kraj', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(917, 'Jihochesky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(918, 'Jihomoravsky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(919, 'Karlovarsky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(920, 'Klecany', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(921, 'Kralovehradecky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(922, 'Liberecky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(923, 'Lipov', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(924, 'Moravskoslezsky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(925, 'Olomoucky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(926, 'Olomoucky Kraj', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(927, 'Pardubicky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(928, 'Plzensky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(929, 'Praha', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(930, 'Rajhrad', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(931, 'Smirice', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(932, 'South Moravian', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(933, 'Straz nad Nisou', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(934, 'Stredochesky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(935, 'Unicov', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(936, 'Ustecky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(937, 'Valletta', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(938, 'Velesin', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(939, 'Vysochina', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(940, 'Zlinsky', 57, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(941, 'Arhus', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(942, 'Bornholm', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(943, 'Frederiksborg', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(944, 'Fyn', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(945, 'Hovedstaden', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(946, 'Kobenhavn', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(947, 'Kobenhavns Amt', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(948, 'Kobenhavns Kommune', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(949, 'Nordjylland', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(950, 'Ribe', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(951, 'Ringkobing', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(952, 'Roervig', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(953, 'Roskilde', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(954, 'Roslev', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(955, 'Sjaelland', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(956, 'Soeborg', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(957, 'Sonderjylland', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(958, 'Storstrom', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(959, 'Syddanmark', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(960, 'Toelloese', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(961, 'Vejle', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(962, 'Vestsjalland', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(963, 'Viborg', 58, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(964, '\'Ali Sabih', 59, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(965, 'Dikhil', 59, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(966, 'Jibuti', 59, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(967, 'Tajurah', 59, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(968, 'Ubuk', 59, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(969, 'Saint Andrew', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(970, 'Saint David', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(971, 'Saint George', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(972, 'Saint John', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(973, 'Saint Joseph', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(974, 'Saint Luke', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(975, 'Saint Mark', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(976, 'Saint Patrick', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(977, 'Saint Paul', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(978, 'Saint Peter', 60, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(979, 'Azua', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(980, 'Bahoruco', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(981, 'Barahona', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(982, 'Dajabon', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(983, 'Distrito Nacional', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(984, 'Duarte', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(985, 'El Seybo', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(986, 'Elias Pina', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(987, 'Espaillat', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(988, 'Hato Mayor', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(989, 'Independencia', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(990, 'La Altagracia', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(991, 'La Romana', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(992, 'La Vega', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(993, 'Maria Trinidad Sanchez', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(994, 'Monsenor Nouel', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(995, 'Monte Cristi', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(996, 'Monte Plata', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(997, 'Pedernales', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(998, 'Peravia', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(999, 'Puerto Plata', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1000, 'Salcedo', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1001, 'Samana', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1002, 'San Cristobal', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1003, 'San Juan', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1004, 'San Pedro de Macoris', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1005, 'Sanchez Ramirez', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1006, 'Santiago', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1007, 'Santiago Rodriguez', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1008, 'Valverde', 61, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1009, 'Aileu', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1010, 'Ainaro', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1011, 'Ambeno', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1012, 'Baucau', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1013, 'Bobonaro', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1014, 'Cova Lima', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1015, 'Dili', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1016, 'Ermera', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1017, 'Lautem', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1018, 'Liquica', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1019, 'Manatuto', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1020, 'Manufahi', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1021, 'Viqueque', 62, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1022, 'Azuay', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1023, 'Bolivar', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1024, 'Canar', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1025, 'Carchi', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1026, 'Chimborazo', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1027, 'Cotopaxi', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1028, 'El Oro', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1029, 'Esmeraldas', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1030, 'Galapagos', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1031, 'Guayas', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1032, 'Imbabura', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1033, 'Loja', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1034, 'Los Rios', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1035, 'Manabi', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1036, 'Morona Santiago', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1037, 'Napo', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1038, 'Orellana', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1039, 'Pastaza', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1040, 'Pichincha', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1041, 'Sucumbios', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1042, 'Tungurahua', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1043, 'Zamora Chinchipe', 63, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1044, 'Aswan', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1045, 'Asyut', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1046, 'Bani Suwayf', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1047, 'Bur Sa\'id', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1048, 'Cairo', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1049, 'Dumyat', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1050, 'Kafr-ash-Shaykh', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1051, 'Matruh', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1052, 'Muhafazat ad Daqahliyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1053, 'Muhafazat al Fayyum', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1054, 'Muhafazat al Gharbiyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1055, 'Muhafazat al Iskandariyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1056, 'Muhafazat al Qahirah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1057, 'Qina', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1058, 'Sawhaj', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1059, 'Sina al-Janubiyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1060, 'Sina ash-Shamaliyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1061, 'ad-Daqahliyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1062, 'al-Bahr-al-Ahmar', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1063, 'al-Buhayrah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1064, 'al-Fayyum', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1065, 'al-Gharbiyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1066, 'al-Iskandariyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1067, 'al-Ismailiyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1068, 'al-Jizah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1069, 'al-Minufiyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1070, 'al-Minya', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1071, 'al-Qahira', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1072, 'al-Qalyubiyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1073, 'al-Uqsur', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1074, 'al-Wadi al-Jadid', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1075, 'as-Suways', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1076, 'ash-Sharqiyah', 64, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1077, 'Ahuachapan', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1078, 'Cabanas', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1079, 'Chalatenango', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1080, 'Cuscatlan', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1081, 'La Libertad', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1082, 'La Paz', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1083, 'La Union', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1084, 'Morazan', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1085, 'San Miguel', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1086, 'San Salvador', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1087, 'San Vicente', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1088, 'Santa Ana', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1089, 'Sonsonate', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1090, 'Usulutan', 65, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1091, 'Annobon', 66, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1092, 'Bioko Norte', 66, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1093, 'Bioko Sur', 66, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1094, 'Centro Sur', 66, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1095, 'Kie-Ntem', 66, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1096, 'Litoral', 66, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1097, 'Wele-Nzas', 66, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1098, 'Anseba', 67, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1099, 'Debub', 67, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1100, 'Debub-Keih-Bahri', 67, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1101, 'Gash-Barka', 67, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1102, 'Maekel', 67, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1103, 'Semien-Keih-Bahri', 67, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1104, 'Harju', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1105, 'Hiiu', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1106, 'Ida-Viru', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1107, 'Jarva', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1108, 'Jogeva', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1109, 'Laane', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1110, 'Laane-Viru', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1111, 'Parnu', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1112, 'Polva', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1113, 'Rapla', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1114, 'Saare', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1115, 'Tartu', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1116, 'Valga', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1117, 'Viljandi', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1118, 'Voru', 68, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1119, 'Addis Abeba', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1120, 'Afar', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1121, 'Amhara', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1122, 'Benishangul', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1123, 'Diredawa', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1124, 'Gambella', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1125, 'Harar', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1126, 'Jigjiga', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1127, 'Mekele', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1128, 'Oromia', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1129, 'Somali', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1130, 'Southern', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1131, 'Tigray', 69, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1132, 'Christmas Island', 70, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1133, 'Cocos Islands', 70, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1134, 'Coral Sea Islands', 70, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1135, 'Falkland Islands', 71, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1136, 'South Georgia', 71, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1137, 'Klaksvik', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1138, 'Nor ara Eysturoy', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1139, 'Nor oy', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1140, 'Sandoy', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1141, 'Streymoy', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1142, 'Su uroy', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1143, 'Sy ra Eysturoy', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1144, 'Torshavn', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1145, 'Vaga', 72, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1146, 'Central', 73, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1147, 'Eastern', 73, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1148, 'Northern', 73, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1149, 'South Pacific', 73, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1150, 'Western', 73, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1151, 'Ahvenanmaa', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1152, 'Etela-Karjala', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1153, 'Etela-Pohjanmaa', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1154, 'Etela-Savo', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1155, 'Etela-Suomen Laani', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1156, 'Ita-Suomen Laani', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1157, 'Ita-Uusimaa', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1158, 'Kainuu', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1159, 'Kanta-Hame', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1160, 'Keski-Pohjanmaa', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1161, 'Keski-Suomi', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1162, 'Kymenlaakso', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1163, 'Lansi-Suomen Laani', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1164, 'Lappi', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1165, 'Northern Savonia', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1166, 'Ostrobothnia', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1167, 'Oulun Laani', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1168, 'Paijat-Hame', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1169, 'Pirkanmaa', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1170, 'Pohjanmaa', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1171, 'Pohjois-Karjala', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1172, 'Pohjois-Pohjanmaa', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1173, 'Pohjois-Savo', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1174, 'Saarijarvi', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1175, 'Satakunta', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1176, 'Southern Savonia', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1177, 'Tavastia Proper', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1178, 'Uleaborgs Lan', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1179, 'Uusimaa', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1180, 'Varsinais-Suomi', 74, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1181, 'Ain', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1182, 'Aisne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1183, 'Albi Le Sequestre', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1184, 'Allier', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1185, 'Alpes-Cote dAzur', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1186, 'Alpes-Maritimes', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1187, 'Alpes-de-Haute-Provence', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1188, 'Alsace', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1189, 'Aquitaine', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1190, 'Ardeche', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1191, 'Ardennes', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1192, 'Ariege', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1193, 'Aube', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1194, 'Aude', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1195, 'Auvergne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1196, 'Aveyron', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1197, 'Bas-Rhin', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1198, 'Basse-Normandie', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1199, 'Bouches-du-Rhone', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1200, 'Bourgogne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1201, 'Bretagne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1202, 'Brittany', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1203, 'Burgundy', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1204, 'Calvados', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1205, 'Cantal', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1206, 'Cedex', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1207, 'Centre', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1208, 'Charente', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1209, 'Charente-Maritime', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1210, 'Cher', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1211, 'Correze', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1212, 'Corse-du-Sud', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1213, 'Cote-d\'Or', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1214, 'Cotes-d\'Armor', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1215, 'Creuse', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1216, 'Crolles', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1217, 'Deux-Sevres', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1218, 'Dordogne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1219, 'Doubs', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1220, 'Drome', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1221, 'Essonne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1222, 'Eure', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1223, 'Eure-et-Loir', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1224, 'Feucherolles', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1225, 'Finistere', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1226, 'Franche-Comte', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1227, 'Gard', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1228, 'Gers', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1229, 'Gironde', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1230, 'Haut-Rhin', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1231, 'Haute-Corse', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1232, 'Haute-Garonne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1233, 'Haute-Loire', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1234, 'Haute-Marne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1235, 'Haute-Saone', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1236, 'Haute-Savoie', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1237, 'Haute-Vienne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1238, 'Hautes-Alpes', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1239, 'Hautes-Pyrenees', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1240, 'Hauts-de-Seine', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1241, 'Herault', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1242, 'Ile-de-France', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1243, 'Ille-et-Vilaine', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1244, 'Indre', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1245, 'Indre-et-Loire', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1246, 'Isere', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1247, 'Jura', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1248, 'Klagenfurt', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1249, 'Landes', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1250, 'Languedoc-Roussillon', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1251, 'Larcay', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1252, 'Le Castellet', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1253, 'Le Creusot', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1254, 'Limousin', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1255, 'Loir-et-Cher', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1256, 'Loire', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1257, 'Loire-Atlantique', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1258, 'Loiret', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1259, 'Lorraine', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1260, 'Lot', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1261, 'Lot-et-Garonne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1262, 'Lower Normandy', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1263, 'Lozere', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1264, 'Maine-et-Loire', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1265, 'Manche', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1266, 'Marne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1267, 'Mayenne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1268, 'Meurthe-et-Moselle', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1269, 'Meuse', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1270, 'Midi-Pyrenees', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1271, 'Morbihan', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1272, 'Moselle', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1273, 'Nievre', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1274, 'Nord', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1275, 'Nord-Pas-de-Calais', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1276, 'Oise', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1277, 'Orne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1278, 'Paris', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1279, 'Pas-de-Calais', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1280, 'Pays de la Loire', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1281, 'Pays-de-la-Loire', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1282, 'Picardy', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1283, 'Puy-de-Dome', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1284, 'Pyrenees-Atlantiques', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1285, 'Pyrenees-Orientales', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1286, 'Quelmes', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1287, 'Rhone', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1288, 'Rhone-Alpes', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1289, 'Saint Ouen', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1290, 'Saint Viatre', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1291, 'Saone-et-Loire', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1292, 'Sarthe', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1293, 'Savoie', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1294, 'Seine-Maritime', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1295, 'Seine-Saint-Denis', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1296, 'Seine-et-Marne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1297, 'Somme', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1298, 'Sophia Antipolis', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1299, 'Souvans', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1300, 'Tarn', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1301, 'Tarn-et-Garonne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1302, 'Territoire de Belfort', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1303, 'Treignac', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1304, 'Upper Normandy', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1305, 'Val-d\'Oise', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1306, 'Val-de-Marne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1307, 'Var', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1308, 'Vaucluse', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1309, 'Vellise', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1310, 'Vendee', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1311, 'Vienne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1312, 'Vosges', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1313, 'Yonne', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1314, 'Yvelines', 75, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1315, 'Cayenne', 76, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1316, 'Saint-Laurent-du-Maroni', 76, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1317, 'Iles du Vent', 77, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1318, 'Iles sous le Vent', 77, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1319, 'Marquesas', 77, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1320, 'Tuamotu', 77, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1321, 'Tubuai', 77, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1322, 'Amsterdam', 78, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1323, 'Crozet Islands', 78, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1324, 'Kerguelen', 78, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1325, 'Estuaire', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1326, 'Haut-Ogooue', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1327, 'Moyen-Ogooue', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1328, 'Ngounie', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1329, 'Nyanga', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1330, 'Ogooue-Ivindo', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1331, 'Ogooue-Lolo', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1332, 'Ogooue-Maritime', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1333, 'Woleu-Ntem', 79, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1334, 'Banjul', 80, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1335, 'Basse', 80, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1336, 'Brikama', 80, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1337, 'Janjanbureh', 80, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1338, 'Kanifing', 80, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1339, 'Kerewan', 80, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1340, 'Kuntaur', 80, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1341, 'Mansakonko', 80, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1342, 'Abhasia', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1343, 'Ajaria', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1344, 'Guria', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1345, 'Imereti', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1346, 'Kaheti', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1347, 'Kvemo Kartli', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1348, 'Mcheta-Mtianeti', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1349, 'Racha', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1350, 'Samagrelo-Zemo Svaneti', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1351, 'Samche-Zhavaheti', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1352, 'Shida Kartli', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1353, 'Tbilisi', 81, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1354, 'Auvergne', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1355, 'Baden-Wurttemberg', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1356, 'Bavaria', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1357, 'Bayern', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1358, 'Beilstein Wurtt', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1359, 'Berlin', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1360, 'Brandenburg', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1361, 'Bremen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1362, 'Dreisbach', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1363, 'Freistaat Bayern', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1364, 'Hamburg', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1365, 'Hannover', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1366, 'Heroldstatt', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1367, 'Hessen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1368, 'Kortenberg', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1369, 'Laasdorf', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1370, 'Land Baden-Wurttemberg', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1371, 'Land Bayern', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1372, 'Land Brandenburg', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1373, 'Land Hessen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1374, 'Land Mecklenburg-Vorpommern', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1375, 'Land Nordrhein-Westfalen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1376, 'Land Rheinland-Pfalz', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1377, 'Land Sachsen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1378, 'Land Sachsen-Anhalt', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1379, 'Land Thuringen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1380, 'Lower Saxony', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1381, 'Mecklenburg-Vorpommern', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1382, 'Mulfingen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1383, 'Munich', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1384, 'Neubeuern', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1385, 'Niedersachsen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1386, 'Noord-Holland', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1387, 'Nordrhein-Westfalen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1388, 'North Rhine-Westphalia', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1389, 'Osterode', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1390, 'Rheinland-Pfalz', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1391, 'Rhineland-Palatinate', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1392, 'Saarland', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1393, 'Sachsen', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1394, 'Sachsen-Anhalt', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1395, 'Saxony', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1396, 'Schleswig-Holstein', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1397, 'Thuringia', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1398, 'Webling', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1399, 'Weinstrabe', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1400, 'schlobborn', 82, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1401, 'Ashanti', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1402, 'Brong-Ahafo', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1403, 'Central', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1404, 'Eastern', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1405, 'Greater Accra', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1406, 'Northern', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1407, 'Upper East', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1408, 'Upper West', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1409, 'Volta', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1410, 'Western', 83, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1411, 'Gibraltar', 84, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1412, 'Acharnes', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1413, 'Ahaia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1414, 'Aitolia kai Akarnania', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1415, 'Argolis', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1416, 'Arkadia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1417, 'Arta', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1418, 'Attica', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1419, 'Attiki', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1420, 'Ayion Oros', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1421, 'Crete', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1422, 'Dodekanisos', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1423, 'Drama', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1424, 'Evia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1425, 'Evritania', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1426, 'Evros', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1427, 'Evvoia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1428, 'Florina', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1429, 'Fokis', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1430, 'Fthiotis', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1431, 'Grevena', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1432, 'Halandri', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1433, 'Halkidiki', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1434, 'Hania', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1435, 'Heraklion', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1436, 'Hios', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1437, 'Ilia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1438, 'Imathia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1439, 'Ioannina', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1440, 'Iraklion', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1441, 'Karditsa', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1442, 'Kastoria', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1443, 'Kavala', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1444, 'Kefallinia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1445, 'Kerkira', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1446, 'Kiklades', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1447, 'Kilkis', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1448, 'Korinthia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1449, 'Kozani', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1450, 'Lakonia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1451, 'Larisa', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1452, 'Lasithi', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1453, 'Lesvos', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1454, 'Levkas', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1455, 'Magnisia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1456, 'Messinia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1457, 'Nomos Attikis', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1458, 'Nomos Zakynthou', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1459, 'Pella', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1460, 'Pieria', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1461, 'Piraios', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1462, 'Preveza', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1463, 'Rethimni', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1464, 'Rodopi', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1465, 'Samos', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1466, 'Serrai', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1467, 'Thesprotia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1468, 'Thessaloniki', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1469, 'Trikala', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1470, 'Voiotia', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1471, 'West Greece', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1472, 'Xanthi', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1473, 'Zakinthos', 85, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1474, 'Aasiaat', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1475, 'Ammassalik', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1476, 'Illoqqortoormiut', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1477, 'Ilulissat', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1478, 'Ivittuut', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1479, 'Kangaatsiaq', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1480, 'Maniitsoq', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1481, 'Nanortalik', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1482, 'Narsaq', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1483, 'Nuuk', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1484, 'Paamiut', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1485, 'Qaanaaq', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1486, 'Qaqortoq', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1487, 'Qasigiannguit', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1488, 'Qeqertarsuaq', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1489, 'Sisimiut', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1490, 'Udenfor kommunal inddeling', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1491, 'Upernavik', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1492, 'Uummannaq', 86, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1493, 'Carriacou-Petite Martinique', 87, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1494, 'Saint Andrew', 87, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1495, 'Saint Davids', 87, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1496, 'Saint George\'s', 87, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1497, 'Saint John', 87, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1498, 'Saint Mark', 87, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1499, 'Saint Patrick', 87, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1500, 'Basse-Terre', 88, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1501, 'Grande-Terre', 88, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1502, 'Iles des Saintes', 88, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1503, 'La Desirade', 88, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1504, 'Marie-Galante', 88, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1505, 'Saint Barthelemy', 88, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1506, 'Saint Martin', 88, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1507, 'Agana Heights', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1508, 'Agat', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1509, 'Barrigada', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1510, 'Chalan-Pago-Ordot', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1511, 'Dededo', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1512, 'Hagatna', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1513, 'Inarajan', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1514, 'Mangilao', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1515, 'Merizo', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1516, 'Mongmong-Toto-Maite', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1517, 'Santa Rita', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1518, 'Sinajana', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1519, 'Talofofo', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1520, 'Tamuning', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1521, 'Yigo', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1522, 'Yona', 89, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1523, 'Alta Verapaz', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1524, 'Baja Verapaz', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1525, 'Chimaltenango', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1526, 'Chiquimula', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1527, 'El Progreso', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1528, 'Escuintla', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1529, 'Guatemala', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1530, 'Huehuetenango', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1531, 'Izabal', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1532, 'Jalapa', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1533, 'Jutiapa', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1534, 'Peten', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1535, 'Quezaltenango', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1536, 'Quiche', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1537, 'Retalhuleu', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1538, 'Sacatepequez', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1539, 'San Marcos', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1540, 'Santa Rosa', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1541, 'Solola', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1542, 'Suchitepequez', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1543, 'Totonicapan', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1544, 'Zacapa', 90, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1545, 'Alderney', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1546, 'Castel', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1547, 'Forest', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1548, 'Saint Andrew', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1549, 'Saint Martin', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1550, 'Saint Peter Port', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1551, 'Saint Pierre du Bois', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1552, 'Saint Sampson', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1553, 'Saint Saviour', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1554, 'Sark', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1555, 'Torteval', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1556, 'Vale', 91, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1557, 'Beyla', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1558, 'Boffa', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1559, 'Boke', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1560, 'Conakry', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1561, 'Coyah', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1562, 'Dabola', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1563, 'Dalaba', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1564, 'Dinguiraye', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1565, 'Faranah', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1566, 'Forecariah', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1567, 'Fria', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1568, 'Gaoual', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1569, 'Gueckedou', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1570, 'Kankan', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1571, 'Kerouane', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1572, 'Kindia', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1573, 'Kissidougou', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1574, 'Koubia', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1575, 'Koundara', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1576, 'Kouroussa', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1577, 'Labe', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1578, 'Lola', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1579, 'Macenta', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1580, 'Mali', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1581, 'Mamou', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1582, 'Mandiana', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1583, 'Nzerekore', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1584, 'Pita', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1585, 'Siguiri', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1586, 'Telimele', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1587, 'Tougue', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1588, 'Yomou', 92, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1589, 'Bafata', 93, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1590, 'Bissau', 93, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1591, 'Bolama', 93, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1592, 'Cacheu', 93, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1593, 'Gabu', 93, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1594, 'Oio', 93, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1595, 'Quinara', 93, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1596, 'Tombali', 93, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1597, 'Barima-Waini', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1598, 'Cuyuni-Mazaruni', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1599, 'Demerara-Mahaica', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1600, 'East Berbice-Corentyne', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1601, 'Essequibo Islands-West Demerar', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1602, 'Mahaica-Berbice', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1603, 'Pomeroon-Supenaam', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1604, 'Potaro-Siparuni', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1605, 'Upper Demerara-Berbice', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1606, 'Upper Takutu-Upper Essequibo', 94, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1607, 'Artibonite', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1608, 'Centre', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1609, 'Grand\'Anse', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1610, 'Nord', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1611, 'Nord-Est', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1612, 'Nord-Ouest', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1613, 'Ouest', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1614, 'Sud', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1615, 'Sud-Est', 95, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1616, 'Heard and McDonald Islands', 96, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1617, 'Atlantida', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1618, 'Choluteca', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1619, 'Colon', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1620, 'Comayagua', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1621, 'Copan', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1622, 'Cortes', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1623, 'Distrito Central', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1624, 'El Paraiso', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1625, 'Francisco Morazan', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1626, 'Gracias a Dios', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1627, 'Intibuca', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1628, 'Islas de la Bahia', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1629, 'La Paz', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1630, 'Lempira', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1631, 'Ocotepeque', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1632, 'Olancho', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1633, 'Santa Barbara', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1634, 'Valle', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1635, 'Yoro', 97, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1636, 'Hong Kong', 98, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1637, 'Bacs-Kiskun', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1638, 'Baranya', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1639, 'Bekes', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1640, 'Borsod-Abauj-Zemplen', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1641, 'Budapest', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1642, 'Csongrad', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1643, 'Fejer', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1644, 'Gyor-Moson-Sopron', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1645, 'Hajdu-Bihar', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1646, 'Heves', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1647, 'Jasz-Nagykun-Szolnok', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1648, 'Komarom-Esztergom', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1649, 'Nograd', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1650, 'Pest', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1651, 'Somogy', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1652, 'Szabolcs-Szatmar-Bereg', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0);
INSERT INTO `states` (`id`, `name`, `country_id`, `created_by`, `created_date`, `modified_by`, `modified_date`, `active`) VALUES
(1653, 'Tolna', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1654, 'Vas', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1655, 'Veszprem', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1656, 'Zala', 99, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1657, 'Austurland', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1658, 'Gullbringusysla', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1659, 'Hofu borgarsva i', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1660, 'Nor urland eystra', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1661, 'Nor urland vestra', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1662, 'Su urland', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1663, 'Su urnes', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1664, 'Vestfir ir', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1665, 'Vesturland', 100, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1666, 'Aceh', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1667, 'Bali', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1668, 'Bangka-Belitung', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1669, 'Banten', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1670, 'Bengkulu', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1671, 'Gandaria', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1672, 'Gorontalo', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1673, 'Jakarta', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1674, 'Jambi', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1675, 'Jawa Barat', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1676, 'Jawa Tengah', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1677, 'Jawa Timur', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1678, 'Kalimantan Barat', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1679, 'Kalimantan Selatan', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1680, 'Kalimantan Tengah', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1681, 'Kalimantan Timur', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1682, 'Kendal', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1683, 'Lampung', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1684, 'Maluku', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1685, 'Maluku Utara', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1686, 'Nusa Tenggara Barat', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1687, 'Nusa Tenggara Timur', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1688, 'Papua', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1689, 'Riau', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1690, 'Riau Kepulauan', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1691, 'Solo', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1692, 'Sulawesi Selatan', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1693, 'Sulawesi Tengah', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1694, 'Sulawesi Tenggara', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1695, 'Sulawesi Utara', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1696, 'Sumatera Barat', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1697, 'Sumatera Selatan', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1698, 'Sumatera Utara', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1699, 'Yogyakarta', 102, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1700, 'Ardabil', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1701, 'Azarbayjan-e Bakhtari', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1702, 'Azarbayjan-e Khavari', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1703, 'Bushehr', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1704, 'Chahar Mahal-e Bakhtiari', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1705, 'Esfahan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1706, 'Fars', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1707, 'Gilan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1708, 'Golestan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1709, 'Hamadan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1710, 'Hormozgan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1711, 'Ilam', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1712, 'Kerman', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1713, 'Kermanshah', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1714, 'Khorasan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1715, 'Khuzestan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1716, 'Kohgiluyeh-e Boyerahmad', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1717, 'Kordestan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1718, 'Lorestan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1719, 'Markazi', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1720, 'Mazandaran', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1721, 'Ostan-e Esfahan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1722, 'Qazvin', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1723, 'Qom', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1724, 'Semnan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1725, 'Sistan-e Baluchestan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1726, 'Tehran', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1727, 'Yazd', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1728, 'Zanjan', 103, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1729, 'Babil', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1730, 'Baghdad', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1731, 'Dahuk', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1732, 'Dhi Qar', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1733, 'Diyala', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1734, 'Erbil', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1735, 'Irbil', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1736, 'Karbala', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1737, 'Kurdistan', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1738, 'Maysan', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1739, 'Ninawa', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1740, 'Salah-ad-Din', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1741, 'Wasit', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1742, 'al-Anbar', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1743, 'al-Basrah', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1744, 'al-Muthanna', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1745, 'al-Qadisiyah', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1746, 'an-Najaf', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1747, 'as-Sulaymaniyah', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1748, 'at-Ta\'mim', 104, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1749, 'Armagh', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1750, 'Carlow', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1751, 'Cavan', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1752, 'Clare', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1753, 'Cork', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1754, 'Donegal', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1755, 'Dublin', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1756, 'Galway', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1757, 'Kerry', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1758, 'Kildare', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1759, 'Kilkenny', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1760, 'Laois', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1761, 'Leinster', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1762, 'Leitrim', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1763, 'Limerick', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1764, 'Loch Garman', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1765, 'Longford', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1766, 'Louth', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1767, 'Mayo', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1768, 'Meath', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1769, 'Monaghan', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1770, 'Offaly', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1771, 'Roscommon', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1772, 'Sligo', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1773, 'Tipperary North Riding', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1774, 'Tipperary South Riding', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1775, 'Ulster', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1776, 'Waterford', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1777, 'Westmeath', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1778, 'Wexford', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1779, 'Wicklow', 105, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1780, 'Beit Hanania', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1781, 'Ben Gurion Airport', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1782, 'Bethlehem', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1783, 'Caesarea', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1784, 'Centre', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1785, 'Gaza', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1786, 'Hadaron', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1787, 'Haifa District', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1788, 'Hamerkaz', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1789, 'Hazafon', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1790, 'Hebron', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1791, 'Jaffa', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1792, 'Jerusalem', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1793, 'Khefa', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1794, 'Kiryat Yam', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1795, 'Lower Galilee', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1796, 'Qalqilya', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1797, 'Talme Elazar', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1798, 'Tel Aviv', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1799, 'Tsafon', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1800, 'Umm El Fahem', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1801, 'Yerushalayim', 106, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1802, 'Abruzzi', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1803, 'Abruzzo', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1804, 'Agrigento', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1805, 'Alessandria', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1806, 'Ancona', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1807, 'Arezzo', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1808, 'Ascoli Piceno', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1809, 'Asti', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1810, 'Avellino', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1811, 'Bari', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1812, 'Basilicata', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1813, 'Belluno', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1814, 'Benevento', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1815, 'Bergamo', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1816, 'Biella', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1817, 'Bologna', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1818, 'Bolzano', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1819, 'Brescia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1820, 'Brindisi', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1821, 'Calabria', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1822, 'Campania', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1823, 'Cartoceto', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1824, 'Caserta', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1825, 'Catania', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1826, 'Chieti', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1827, 'Como', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1828, 'Cosenza', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1829, 'Cremona', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1830, 'Cuneo', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1831, 'Emilia-Romagna', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1832, 'Ferrara', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1833, 'Firenze', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1834, 'Florence', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1835, 'Forli-Cesena ', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1836, 'Friuli-Venezia Giulia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1837, 'Frosinone', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1838, 'Genoa', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1839, 'Gorizia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1840, 'L\'Aquila', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1841, 'Lazio', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1842, 'Lecce', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1843, 'Lecco', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1845, 'Liguria', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1846, 'Lodi', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1847, 'Lombardia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1848, 'Lombardy', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1849, 'Macerata', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1850, 'Mantova', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1851, 'Marche', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1852, 'Messina', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1853, 'Milan', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1854, 'Modena', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1855, 'Molise', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1856, 'Molteno', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1857, 'Montenegro', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1858, 'Monza and Brianza', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1859, 'Naples', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1860, 'Novara', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1861, 'Padova', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1862, 'Parma', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1863, 'Pavia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1864, 'Perugia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1865, 'Pesaro-Urbino', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1866, 'Piacenza', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1867, 'Piedmont', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1868, 'Piemonte', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1869, 'Pisa', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1870, 'Pordenone', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1871, 'Potenza', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1872, 'Puglia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1873, 'Reggio Emilia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1874, 'Rimini', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1875, 'Roma', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1876, 'Salerno', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1877, 'Sardegna', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1878, 'Sassari', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1879, 'Savona', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1880, 'Sicilia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1881, 'Siena', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1882, 'Sondrio', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1883, 'South Tyrol', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1884, 'Taranto', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1885, 'Teramo', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1886, 'Torino', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1887, 'Toscana', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1888, 'Trapani', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1889, 'Trentino-Alto Adige', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1890, 'Trento', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1891, 'Treviso', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1892, 'Udine', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1893, 'Umbria', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1894, 'Valle d\'Aosta', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1895, 'Varese', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1896, 'Veneto', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1897, 'Venezia', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1898, 'Verbano-Cusio-Ossola', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1899, 'Vercelli', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1900, 'Verona', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1901, 'Vicenza', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1902, 'Viterbo', 107, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1903, 'Buxoro Viloyati', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1904, 'Clarendon', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1905, 'Hanover', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1906, 'Kingston', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1907, 'Manchester', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1908, 'Portland', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1909, 'Saint Andrews', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1910, 'Saint Ann', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1911, 'Saint Catherine', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1912, 'Saint Elizabeth', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1913, 'Saint James', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1914, 'Saint Mary', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1915, 'Saint Thomas', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1916, 'Trelawney', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1917, 'Westmoreland', 108, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1918, 'Aichi', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1919, 'Akita', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1920, 'Aomori', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1921, 'Chiba', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1922, 'Ehime', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1923, 'Fukui', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1924, 'Fukuoka', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1925, 'Fukushima', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1926, 'Gifu', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1927, 'Gumma', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1928, 'Hiroshima', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1929, 'Hokkaido', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1930, 'Hyogo', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1931, 'Ibaraki', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1932, 'Ishikawa', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1933, 'Iwate', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1934, 'Kagawa', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1935, 'Kagoshima', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1936, 'Kanagawa', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1937, 'Kanto', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1938, 'Kochi', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1939, 'Kumamoto', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1940, 'Kyoto', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1941, 'Mie', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1942, 'Miyagi', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1943, 'Miyazaki', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1944, 'Nagano', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1945, 'Nagasaki', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1946, 'Nara', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1947, 'Niigata', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1948, 'Oita', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1949, 'Okayama', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1950, 'Okinawa', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1951, 'Osaka', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1952, 'Saga', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1953, 'Saitama', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1954, 'Shiga', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1955, 'Shimane', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1956, 'Shizuoka', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1957, 'Tochigi', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1958, 'Tokushima', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1959, 'Tokyo', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1960, 'Tottori', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1961, 'Toyama', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1962, 'Wakayama', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1963, 'Yamagata', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1964, 'Yamaguchi', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1965, 'Yamanashi', 109, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1966, 'Grouville', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1967, 'Saint Brelade', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1968, 'Saint Clement', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1969, 'Saint Helier', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1970, 'Saint John', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1971, 'Saint Lawrence', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1972, 'Saint Martin', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1973, 'Saint Mary', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1974, 'Saint Peter', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1975, 'Saint Saviour', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1976, 'Trinity', 110, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1977, '\'Ajlun', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1978, 'Amman', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1979, 'Irbid', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1980, 'Jarash', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1981, 'Ma\'an', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1982, 'Madaba', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1983, 'al-\'Aqabah', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1984, 'al-Balqa\'', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1985, 'al-Karak', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1986, 'al-Mafraq', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1987, 'at-Tafilah', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1988, 'az-Zarqa\'', 111, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1989, 'Akmecet', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1990, 'Akmola', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1991, 'Aktobe', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1992, 'Almati', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1993, 'Atirau', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1994, 'Batis Kazakstan', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1995, 'Burlinsky Region', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1996, 'Karagandi', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1997, 'Kostanay', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1998, 'Mankistau', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(1999, 'Ontustik Kazakstan', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2000, 'Pavlodar', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2001, 'Sigis Kazakstan', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2002, 'Soltustik Kazakstan', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2003, 'Taraz', 112, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2004, 'Central', 113, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2005, 'Coast', 113, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2006, 'Eastern', 113, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2007, 'Nairobi', 113, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2008, 'North Eastern', 113, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2009, 'Nyanza', 113, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2010, 'Rift Valley', 113, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2011, 'Western', 113, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2012, 'Abaiang', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2013, 'Abemana', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2014, 'Aranuka', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2015, 'Arorae', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2016, 'Banaba', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2017, 'Beru', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2018, 'Butaritari', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2019, 'Kiritimati', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2020, 'Kuria', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2021, 'Maiana', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2022, 'Makin', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2023, 'Marakei', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2024, 'Nikunau', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2025, 'Nonouti', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2026, 'Ooa', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2027, 'Phoenix Islands', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2028, 'Tabiteuea North', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2029, 'Tabiteuea South', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2030, 'Tabuaeran', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2031, 'Tamana', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2032, 'Tarawa North', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2033, 'Tarawa South', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2034, 'Teraina', 114, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2035, 'Chagangdo', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2036, 'Hamgyeongbukto', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2037, 'Hamgyeongnamdo', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2038, 'Hwanghaebukto', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2039, 'Hwanghaenamdo', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2040, 'Kaeseong', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2041, 'Kangweon', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2042, 'Nampo', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2043, 'Pyeonganbukto', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2044, 'Pyeongannamdo', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2045, 'Pyeongyang', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2046, 'Yanggang', 115, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2047, 'Busan', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2048, 'Cheju', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2049, 'Chollabuk', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2050, 'Chollanam', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2051, 'Chungbuk', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2052, 'Chungcheongbuk', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2053, 'Chungcheongnam', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2054, 'Chungnam', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2055, 'Daegu', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2056, 'Gangwon-do', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2057, 'Goyang-si', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2058, 'Gyeonggi-do', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2059, 'Gyeongsang ', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2060, 'Gyeongsangnam-do', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2061, 'Incheon', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2062, 'Jeju-Si', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2063, 'Jeonbuk', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2064, 'Kangweon', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2065, 'Kwangju', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2066, 'Kyeonggi', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2067, 'Kyeongsangbuk', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2068, 'Kyeongsangnam', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2069, 'Kyonggi-do', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2070, 'Kyungbuk-Do', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2071, 'Kyunggi-Do', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2072, 'Kyunggi-do', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2073, 'Pusan', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2074, 'Seoul', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2075, 'Sudogwon', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2076, 'Taegu', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2077, 'Taejeon', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2078, 'Taejon-gwangyoksi', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2079, 'Ulsan', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2080, 'Wonju', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2081, 'gwangyoksi', 116, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2082, 'Al Asimah', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2083, 'Hawalli', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2084, 'Mishref', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2085, 'Qadesiya', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2086, 'Safat', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2087, 'Salmiya', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2088, 'al-Ahmadi', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2089, 'al-Farwaniyah', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2090, 'al-Jahra', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2091, 'al-Kuwayt', 117, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2092, 'Batken', 118, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2093, 'Bishkek', 118, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2094, 'Chui', 118, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2095, 'Issyk-Kul', 118, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2096, 'Jalal-Abad', 118, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2097, 'Naryn', 118, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2098, 'Osh', 118, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2099, 'Talas', 118, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2100, 'Attopu', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2101, 'Bokeo', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2102, 'Bolikhamsay', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2103, 'Champasak', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2104, 'Houaphanh', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2105, 'Khammouane', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2106, 'Luang Nam Tha', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2107, 'Luang Prabang', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2108, 'Oudomxay', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2109, 'Phongsaly', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2110, 'Saravan', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2111, 'Savannakhet', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2112, 'Sekong', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2113, 'Viangchan Prefecture', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2114, 'Viangchan Province', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2115, 'Xaignabury', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2116, 'Xiang Khuang', 119, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2117, 'Aizkraukles', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2118, 'Aluksnes', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2119, 'Balvu', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2120, 'Bauskas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2121, 'Cesu', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2122, 'Daugavpils', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2123, 'Daugavpils City', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2124, 'Dobeles', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2125, 'Gulbenes', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2126, 'Jekabspils', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2127, 'Jelgava', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2128, 'Jelgavas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2129, 'Jurmala City', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2130, 'Kraslavas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2131, 'Kuldigas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2132, 'Liepaja', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2133, 'Liepajas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2134, 'Limbazhu', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2135, 'Ludzas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2136, 'Madonas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2137, 'Ogres', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2138, 'Preilu', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2139, 'Rezekne', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2140, 'Rezeknes', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2141, 'Riga', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2142, 'Rigas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2143, 'Saldus', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2144, 'Talsu', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2145, 'Tukuma', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2146, 'Valkas', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2147, 'Valmieras', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2148, 'Ventspils', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2149, 'Ventspils City', 120, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2150, 'Beirut', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2151, 'Jabal Lubnan', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2152, 'Mohafazat Liban-Nord', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2153, 'Mohafazat Mont-Liban', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2154, 'Sidon', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2155, 'al-Biqa', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2156, 'al-Janub', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2157, 'an-Nabatiyah', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2158, 'ash-Shamal', 121, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2159, 'Berea', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2160, 'Butha-Buthe', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2161, 'Leribe', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2162, 'Mafeteng', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2163, 'Maseru', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2164, 'Mohale\'s Hoek', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2165, 'Mokhotlong', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2166, 'Qacha\'s Nek', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2167, 'Quthing', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2168, 'Thaba-Tseka', 122, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2169, 'Bomi', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2170, 'Bong', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2171, 'Grand Bassa', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2172, 'Grand Cape Mount', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2173, 'Grand Gedeh', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2174, 'Loffa', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2175, 'Margibi', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2176, 'Maryland and Grand Kru', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2177, 'Montserrado', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2178, 'Nimba', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2179, 'Rivercess', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2180, 'Sinoe', 123, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2181, 'Ajdabiya', 124, 0, '2019-04-26 07:22:55', 0, NULL, 0),
(2182, 'Fezzan', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2183, 'Banghazi', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2184, 'Darnah', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2185, 'Ghadamis', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2186, 'Gharyan', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2187, 'Misratah', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2188, 'Murzuq', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2189, 'Sabha', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2190, 'Sawfajjin', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2191, 'Surt', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2192, 'Tarabulus', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2193, 'Tarhunah', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2194, 'Tripolitania', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2195, 'Tubruq', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2196, 'Yafran', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2197, 'Zlitan', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2198, 'al-\'Aziziyah', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2199, 'al-Fatih', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2200, 'al-Jabal al Akhdar', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2201, 'al-Jufrah', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2202, 'al-Khums', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2203, 'al-Kufrah', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2204, 'an-Nuqat al-Khams', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2205, 'ash-Shati\'', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2206, 'az-Zawiyah', 124, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2207, 'Balzers', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2208, 'Eschen', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2209, 'Gamprin', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2210, 'Mauren', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2211, 'Planken', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2212, 'Ruggell', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2213, 'Schaan', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2214, 'Schellenberg', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2215, 'Triesen', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2216, 'Triesenberg', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2217, 'Vaduz', 125, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2218, 'Alytaus', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2219, 'Anyksciai', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2220, 'Kauno', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2221, 'Klaipedos', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2222, 'Marijampoles', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2223, 'Panevezhio', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2224, 'Panevezys', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2225, 'Shiauliu', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2226, 'Taurages', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2227, 'Telshiu', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2228, 'Telsiai', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2229, 'Utenos', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2230, 'Vilniaus', 126, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2231, 'Capellen', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2232, 'Clervaux', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2233, 'Diekirch', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2234, 'Echternach', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2235, 'Esch-sur-Alzette', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2236, 'Grevenmacher', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2237, 'Luxembourg', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2238, 'Mersch', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2239, 'Redange', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2240, 'Remich', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2241, 'Vianden', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2242, 'Wiltz', 127, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2243, 'Macau', 128, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2244, 'Berovo', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2245, 'Bitola', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2246, 'Brod', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2247, 'Debar', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2248, 'Delchevo', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2249, 'Demir Hisar', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2250, 'Gevgelija', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2251, 'Gostivar', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2252, 'Kavadarci', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2253, 'Kichevo', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2254, 'Kochani', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2255, 'Kratovo', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2256, 'Kriva Palanka', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2257, 'Krushevo', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2258, 'Kumanovo', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2259, 'Negotino', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2260, 'Ohrid', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2261, 'Prilep', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2262, 'Probishtip', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2263, 'Radovish', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2264, 'Resen', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2265, 'Shtip', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2266, 'Skopje', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2267, 'Struga', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2268, 'Strumica', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2269, 'Sveti Nikole', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2270, 'Tetovo', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2271, 'Valandovo', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2272, 'Veles', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2273, 'Vinica', 129, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2274, 'Antananarivo', 130, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2275, 'Antsiranana', 130, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2276, 'Fianarantsoa', 130, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2277, 'Mahajanga', 130, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2278, 'Toamasina', 130, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2279, 'Toliary', 130, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2280, 'Balaka', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2281, 'Blantyre City', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2282, 'Chikwawa', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2283, 'Chiradzulu', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2284, 'Chitipa', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2285, 'Dedza', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2286, 'Dowa', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2287, 'Karonga', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2288, 'Kasungu', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2289, 'Lilongwe City', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2290, 'Machinga', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2291, 'Mangochi', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2292, 'Mchinji', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2293, 'Mulanje', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2294, 'Mwanza', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2295, 'Mzimba', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2296, 'Mzuzu City', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2297, 'Nkhata Bay', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2298, 'Nkhotakota', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2299, 'Nsanje', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2300, 'Ntcheu', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2301, 'Ntchisi', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2302, 'Phalombe', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2303, 'Rumphi', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2304, 'Salima', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2305, 'Thyolo', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2306, 'Zomba Municipality', 131, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2307, 'Johor', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2308, 'Kedah', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2309, 'Kelantan', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2310, 'Kuala Lumpur', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2311, 'Labuan', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2312, 'Melaka', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2313, 'Negeri Johor', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2314, 'Negeri Sembilan', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2315, 'Pahang', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2316, 'Penang', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2317, 'Perak', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2318, 'Perlis', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2319, 'Pulau Pinang', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2320, 'Sabah', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2321, 'Sarawak', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2322, 'Selangor', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2323, 'Sembilan', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2324, 'Terengganu', 132, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2325, 'Alif Alif', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2326, 'Alif Dhaal', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2327, 'Baa', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2328, 'Dhaal', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2329, 'Faaf', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2330, 'Gaaf Alif', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2331, 'Gaaf Dhaal', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2332, 'Ghaviyani', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2333, 'Haa Alif', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2334, 'Haa Dhaal', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2335, 'Kaaf', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2336, 'Laam', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2337, 'Lhaviyani', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2338, 'Male', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2339, 'Miim', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2340, 'Nuun', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2341, 'Raa', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2342, 'Shaviyani', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2343, 'Siin', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2344, 'Thaa', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2345, 'Vaav', 133, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2346, 'Bamako', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2347, 'Gao', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2348, 'Kayes', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2349, 'Kidal', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2350, 'Koulikoro', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2351, 'Mopti', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2352, 'Segou', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2353, 'Sikasso', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2354, 'Tombouctou', 134, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2355, 'Gozo and Comino', 135, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2356, 'Inner Harbour', 135, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2357, 'Northern', 135, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2358, 'Outer Harbour', 135, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2359, 'South Eastern', 135, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2360, 'Valletta', 135, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2361, 'Western', 135, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2362, 'Castletown', 136, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2363, 'Douglas', 136, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2364, 'Laxey', 136, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2365, 'Onchan', 136, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2366, 'Peel', 136, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2367, 'Port Erin', 136, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2368, 'Port Saint Mary', 136, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2369, 'Ramsey', 136, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2370, 'Ailinlaplap', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2371, 'Ailuk', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2372, 'Arno', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2373, 'Aur', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2374, 'Bikini', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2375, 'Ebon', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2376, 'Enewetak', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2377, 'Jabat', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2378, 'Jaluit', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2379, 'Kili', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2380, 'Kwajalein', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2381, 'Lae', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2382, 'Lib', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2383, 'Likiep', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2384, 'Majuro', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2385, 'Maloelap', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2386, 'Mejit', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2387, 'Mili', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2388, 'Namorik', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2389, 'Namu', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2390, 'Rongelap', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2391, 'Ujae', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2392, 'Utrik', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2393, 'Wotho', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2394, 'Wotje', 137, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2395, 'Fort-de-France', 138, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2396, 'La Trinite', 138, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2397, 'Le Marin', 138, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2398, 'Saint-Pierre', 138, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2399, 'Adrar', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2400, 'Assaba', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2401, 'Brakna', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2402, 'Dhakhlat Nawadibu', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2403, 'Hudh-al-Gharbi', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2404, 'Hudh-ash-Sharqi', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2405, 'Inshiri', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2406, 'Nawakshut', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2407, 'Qidimagha', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2408, 'Qurqul', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2409, 'Taqant', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2410, 'Tiris Zammur', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2411, 'Trarza', 139, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2412, 'Black River', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2413, 'Eau Coulee', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2414, 'Flacq', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2415, 'Floreal', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2416, 'Grand Port', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2417, 'Moka', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2418, 'Pamplempousses', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2419, 'Plaines Wilhelm', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2420, 'Port Louis', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2421, 'Riviere du Rempart', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2422, 'Rodrigues', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2423, 'Rose Hill', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2424, 'Savanne', 140, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2425, 'Mayotte', 141, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2426, 'Pamanzi', 141, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2427, 'Aguascalientes', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2428, 'Baja California', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2429, 'Baja California Sur', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2430, 'Campeche', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2431, 'Chiapas', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2432, 'Chihuahua', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2433, 'Coahuila', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2434, 'Colima', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2435, 'Distrito Federal', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2436, 'Durango', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2437, 'Estado de Mexico', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2438, 'Guanajuato', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2439, 'Guerrero', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2440, 'Hidalgo', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2441, 'Jalisco', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2442, 'Mexico', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2443, 'Michoacan', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2444, 'Morelos', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2445, 'Nayarit', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2446, 'Nuevo Leon', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2447, 'Oaxaca', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2448, 'Puebla', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2449, 'Queretaro', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2450, 'Quintana Roo', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2451, 'San Luis Potosi', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2452, 'Sinaloa', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2453, 'Sonora', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2454, 'Tabasco', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2455, 'Tamaulipas', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2456, 'Tlaxcala', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2457, 'Veracruz', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2458, 'Yucatan', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2459, 'Zacatecas', 142, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2460, 'Chuuk', 143, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2461, 'Kusaie', 143, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2462, 'Pohnpei', 143, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2463, 'Yap', 143, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2464, 'Balti', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2465, 'Cahul', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0);
INSERT INTO `states` (`id`, `name`, `country_id`, `created_by`, `created_date`, `modified_by`, `modified_date`, `active`) VALUES
(2466, 'Chisinau', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2467, 'Chisinau Oras', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2468, 'Edinet', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2469, 'Gagauzia', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2470, 'Lapusna', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2471, 'Orhei', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2472, 'Soroca', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2473, 'Taraclia', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2474, 'Tighina', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2475, 'Transnistria', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2476, 'Ungheni', 144, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2477, 'Fontvieille', 145, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2478, 'La Condamine', 145, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2479, 'Monaco-Ville', 145, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2480, 'Monte Carlo', 145, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2481, 'Arhangaj', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2482, 'Bajan-Olgij', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2483, 'Bajanhongor', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2484, 'Bulgan', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2485, 'Darhan-Uul', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2486, 'Dornod', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2487, 'Dornogovi', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2488, 'Dundgovi', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2489, 'Govi-Altaj', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2490, 'Govisumber', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2491, 'Hentij', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2492, 'Hovd', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2493, 'Hovsgol', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2494, 'Omnogovi', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2495, 'Orhon', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2496, 'Ovorhangaj', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2497, 'Selenge', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2498, 'Suhbaatar', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2499, 'Tov', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2500, 'Ulaanbaatar', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2501, 'Uvs', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2502, 'Zavhan', 146, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2503, 'Montserrat', 147, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2504, 'Agadir', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2505, 'Casablanca', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2506, 'Chaouia-Ouardigha', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2507, 'Doukkala-Abda', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2508, 'Fes-Boulemane', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2509, 'Gharb-Chrarda-Beni Hssen', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2510, 'Guelmim', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2511, 'Kenitra', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2512, 'Marrakech-Tensift-Al Haouz', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2513, 'Meknes-Tafilalet', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2514, 'Oriental', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2515, 'Oujda', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2516, 'Province de Tanger', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2517, 'Rabat-Sale-Zammour-Zaer', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2518, 'Sala Al Jadida', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2519, 'Settat', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2520, 'Souss Massa-Draa', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2521, 'Tadla-Azilal', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2522, 'Tangier-Tetouan', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2523, 'Taza-Al Hoceima-Taounate', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2524, 'Wilaya de Casablanca', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2525, 'Wilaya de Rabat-Sale', 148, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2526, 'Cabo Delgado', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2527, 'Gaza', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2528, 'Inhambane', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2529, 'Manica', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2530, 'Maputo', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2531, 'Maputo Provincia', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2532, 'Nampula', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2533, 'Niassa', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2534, 'Sofala', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2535, 'Tete', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2536, 'Zambezia', 149, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2537, 'Ayeyarwady', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2538, 'Bago', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2539, 'Chin', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2540, 'Kachin', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2541, 'Kayah', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2542, 'Kayin', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2543, 'Magway', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2544, 'Mandalay', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2545, 'Mon', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2546, 'Nay Pyi Taw', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2547, 'Rakhine', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2548, 'Sagaing', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2549, 'Shan', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2550, 'Tanintharyi', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2551, 'Yangon', 150, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2552, 'Caprivi', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2553, 'Erongo', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2554, 'Hardap', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2555, 'Karas', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2556, 'Kavango', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2557, 'Khomas', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2558, 'Kunene', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2559, 'Ohangwena', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2560, 'Omaheke', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2561, 'Omusati', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2562, 'Oshana', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2563, 'Oshikoto', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2564, 'Otjozondjupa', 151, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2565, 'Yaren', 152, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2566, 'Bagmati', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2567, 'Bheri', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2568, 'Dhawalagiri', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2569, 'Gandaki', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2570, 'Janakpur', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2571, 'Karnali', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2572, 'Koshi', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2573, 'Lumbini', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2574, 'Mahakali', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2575, 'Mechi', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2576, 'Narayani', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2577, 'Rapti', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2578, 'Sagarmatha', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2579, 'Seti', 153, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2580, 'Bonaire', 154, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2581, 'Curacao', 154, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2582, 'Saba', 154, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2583, 'Sint Eustatius', 154, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2584, 'Sint Maarten', 154, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2585, 'Amsterdam', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2586, 'Benelux', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2587, 'Drenthe', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2588, 'Flevoland', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2589, 'Friesland', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2590, 'Gelderland', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2591, 'Groningen', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2592, 'Limburg', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2593, 'Noord-Brabant', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2594, 'Noord-Holland', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2595, 'Overijssel', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2596, 'South Holland', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2597, 'Utrecht', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2598, 'Zeeland', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2599, 'Zuid-Holland', 155, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2600, 'Iles', 156, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2601, 'Nord', 156, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2602, 'Sud', 156, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2603, 'Area Outside Region', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2604, 'Auckland', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2605, 'Bay of Plenty', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2606, 'Canterbury', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2607, 'Christchurch', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2608, 'Gisborne', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2609, 'Hawke\'s Bay', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2610, 'Manawatu-Wanganui', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2611, 'Marlborough', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2612, 'Nelson', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2613, 'Northland', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2614, 'Otago', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2615, 'Rodney', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2616, 'Southland', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2617, 'Taranaki', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2618, 'Tasman', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2619, 'Waikato', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2620, 'Wellington', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2621, 'West Coast', 157, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2622, 'Atlantico Norte', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2623, 'Atlantico Sur', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2624, 'Boaco', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2625, 'Carazo', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2626, 'Chinandega', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2627, 'Chontales', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2628, 'Esteli', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2629, 'Granada', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2630, 'Jiega', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2631, 'Leon', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2632, 'Madriz', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2633, 'Managua', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2634, 'Masaya', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2635, 'Matagalpa', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2636, 'Nueva Segovia', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2637, 'Rio San Juan', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2638, 'Rivas', 158, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2639, 'Agadez', 159, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2640, 'Diffa', 159, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2641, 'Dosso', 159, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2642, 'Maradi', 159, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2643, 'Niamey', 159, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2644, 'Tahoua', 159, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2645, 'Tillabery', 159, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2646, 'Zinder', 159, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2647, 'Abia', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2648, 'Abuja Federal Capital Territor', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2649, 'Adamawa', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2650, 'Akwa Ibom', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2651, 'Anambra', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2652, 'Bauchi', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2653, 'Bayelsa', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2654, 'Benue', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2655, 'Borno', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2656, 'Cross River', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2657, 'Delta', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2658, 'Ebonyi', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2659, 'Edo', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2660, 'Ekiti', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2661, 'Enugu', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2662, 'Gombe', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2663, 'Imo', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2664, 'Jigawa', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2665, 'Kaduna', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2666, 'Kano', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2667, 'Katsina', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2668, 'Kebbi', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2669, 'Kogi', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2670, 'Kwara', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2671, 'Lagos', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2672, 'Nassarawa', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2673, 'Niger', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2674, 'Ogun', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2675, 'Ondo', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2676, 'Osun', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2677, 'Oyo', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2678, 'Plateau', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2679, 'Rivers', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2680, 'Sokoto', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2681, 'Taraba', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2682, 'Yobe', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2683, 'Zamfara', 160, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2684, 'Niue', 161, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2685, 'Norfolk Island', 162, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2686, 'Northern Islands', 163, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2687, 'Rota', 163, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2688, 'Saipan', 163, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2689, 'Tinian', 163, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2690, 'Akershus', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2691, 'Aust Agder', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2692, 'Bergen', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2693, 'Buskerud', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2694, 'Finnmark', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2695, 'Hedmark', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2696, 'Hordaland', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2697, 'Moere og Romsdal', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2698, 'Nord Trondelag', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2699, 'Nordland', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2700, 'Oestfold', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2701, 'Oppland', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2702, 'Oslo', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2703, 'Rogaland', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2704, 'Soer Troendelag', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2705, 'Sogn og Fjordane', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2706, 'Stavern', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2707, 'Sykkylven', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2708, 'Telemark', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2709, 'Troms', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2710, 'Vest Agder', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2711, 'Vestfold', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2712, 'ÃƒÂ˜stfold', 164, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2713, 'Al Buraimi', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2714, 'Dhufar', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2715, 'Masqat', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2716, 'Musandam', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2717, 'Rusayl', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2718, 'Wadi Kabir', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2719, 'ad-Dakhiliyah', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2720, 'adh-Dhahirah', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2721, 'al-Batinah', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2722, 'ash-Sharqiyah', 165, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2723, 'Baluchistan', 166, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2724, 'Federal Capital Area', 166, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2725, 'Federally administered Tribal ', 166, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2726, 'North-West Frontier', 166, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2727, 'Northern Areas', 166, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2728, 'Punjab', 166, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2729, 'Sind', 166, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2730, 'Aimeliik', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2731, 'Airai', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2732, 'Angaur', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2733, 'Hatobohei', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2734, 'Kayangel', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2735, 'Koror', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2736, 'Melekeok', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2737, 'Ngaraard', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2738, 'Ngardmau', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2739, 'Ngaremlengui', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2740, 'Ngatpang', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2741, 'Ngchesar', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2742, 'Ngerchelong', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2743, 'Ngiwal', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2744, 'Peleliu', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2745, 'Sonsorol', 167, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2746, 'Ariha', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2747, 'Bayt Lahm', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2748, 'Bethlehem', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2749, 'Dayr-al-Balah', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2750, 'Ghazzah', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2751, 'Ghazzah ash-Shamaliyah', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2752, 'Janin', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2753, 'Khan Yunis', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2754, 'Nabulus', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2755, 'Qalqilyah', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2756, 'Rafah', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2757, 'Ram Allah wal-Birah', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2758, 'Salfit', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2759, 'Tubas', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2760, 'Tulkarm', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2761, 'al-Khalil', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2762, 'al-Quds', 168, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2763, 'Bocas del Toro', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2764, 'Chiriqui', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2765, 'Cocle', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2766, 'Colon', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2767, 'Darien', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2768, 'Embera', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2769, 'Herrera', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2770, 'Kuna Yala', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2771, 'Los Santos', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2772, 'Ngobe Bugle', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2773, 'Panama', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2774, 'Veraguas', 169, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2775, 'East New Britain', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2776, 'East Sepik', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2777, 'Eastern Highlands', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2778, 'Enga', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2779, 'Fly River', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2780, 'Gulf', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2781, 'Madang', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2782, 'Manus', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2783, 'Milne Bay', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2784, 'Morobe', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2785, 'National Capital District', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2786, 'New Ireland', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2787, 'North Solomons', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2788, 'Oro', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2789, 'Sandaun', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2790, 'Simbu', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2791, 'Southern Highlands', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2792, 'West New Britain', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2793, 'Western Highlands', 170, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2794, 'Alto Paraguay', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2795, 'Alto Parana', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2796, 'Amambay', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2797, 'Asuncion', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2798, 'Boqueron', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2799, 'Caaguazu', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2800, 'Caazapa', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2801, 'Canendiyu', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2802, 'Central', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2803, 'Concepcion', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2804, 'Cordillera', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2805, 'Guaira', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2806, 'Itapua', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2807, 'Misiones', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2808, 'Neembucu', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2809, 'Paraguari', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2810, 'Presidente Hayes', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2811, 'San Pedro', 171, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2812, 'Amazonas', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2813, 'Ancash', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2814, 'Apurimac', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2815, 'Arequipa', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2816, 'Ayacucho', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2817, 'Cajamarca', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2818, 'Cusco', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2819, 'Huancavelica', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2820, 'Huanuco', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2821, 'Ica', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2822, 'Junin', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2823, 'La Libertad', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2824, 'Lambayeque', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2825, 'Lima y Callao', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2826, 'Loreto', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2827, 'Madre de Dios', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2828, 'Moquegua', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2829, 'Pasco', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2830, 'Piura', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2831, 'Puno', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2832, 'San Martin', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2833, 'Tacna', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2834, 'Tumbes', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2835, 'Ucayali', 172, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2836, 'Batangas', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2837, 'Bicol', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2838, 'Bulacan', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2839, 'Cagayan', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2840, 'Caraga', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2841, 'Central Luzon', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2842, 'Central Mindanao', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2843, 'Central Visayas', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2844, 'Cordillera', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2845, 'Davao', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2846, 'Eastern Visayas', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2847, 'Greater Metropolitan Area', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2848, 'Ilocos', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2849, 'Laguna', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2850, 'Luzon', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2851, 'Mactan', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2852, 'Metropolitan Manila Area', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2853, 'Muslim Mindanao', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2854, 'Northern Mindanao', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2855, 'Southern Mindanao', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2856, 'Southern Tagalog', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2857, 'Western Mindanao', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2858, 'Western Visayas', 173, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2859, 'Pitcairn Island', 174, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2860, 'Biale Blota', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2861, 'Dobroszyce', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2862, 'Dolnoslaskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2863, 'Dziekanow Lesny', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2864, 'Hopowo', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2865, 'Kartuzy', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2866, 'Koscian', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2867, 'Krakow', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2868, 'Kujawsko-Pomorskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2869, 'Lodzkie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2870, 'Lubelskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2871, 'Lubuskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2872, 'Malomice', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2873, 'Malopolskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2874, 'Mazowieckie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2875, 'Mirkow', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2876, 'Opolskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2877, 'Ostrowiec', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2878, 'Podkarpackie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2879, 'Podlaskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2880, 'Polska', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2881, 'Pomorskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2882, 'Poznan', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2883, 'Pruszkow', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2884, 'Rymanowska', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2885, 'Rzeszow', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2886, 'Slaskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2887, 'Stare Pole', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2888, 'Swietokrzyskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2889, 'Warminsko-Mazurskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2890, 'Warsaw', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2891, 'Wejherowo', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2892, 'Wielkopolskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2893, 'Wroclaw', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2894, 'Zachodnio-Pomorskie', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2895, 'Zukowo', 175, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2896, 'Abrantes', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2897, 'Acores', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2898, 'Alentejo', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2899, 'Algarve', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2900, 'Braga', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2901, 'Centro', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2902, 'Distrito de Leiria', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2903, 'Distrito de Viana do Castelo', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2904, 'Distrito de Vila Real', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2905, 'Distrito do Porto', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2906, 'Lisboa e Vale do Tejo', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2907, 'Madeira', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2908, 'Norte', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2909, 'Paivas', 176, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2910, 'Arecibo', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2911, 'Bayamon', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2912, 'Carolina', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2913, 'Florida', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2914, 'Guayama', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2915, 'Humacao', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2916, 'Mayaguez-Aguadilla', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2917, 'Ponce', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2918, 'Salinas', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2919, 'San Juan', 177, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2920, 'Doha', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2921, 'Jarian-al-Batnah', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2922, 'Umm Salal', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2923, 'ad-Dawhah', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2924, 'al-Ghuwayriyah', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2925, 'al-Jumayliyah', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2926, 'al-Khawr', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2927, 'al-Wakrah', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2928, 'ar-Rayyan', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2929, 'ash-Shamal', 178, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2930, 'Saint-Benoit', 179, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2931, 'Saint-Denis', 179, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2932, 'Saint-Paul', 179, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2933, 'Saint-Pierre', 179, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2934, 'Alba', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2935, 'Arad', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2936, 'Arges', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2937, 'Bacau', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2938, 'Bihor', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2939, 'Bistrita-Nasaud', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2940, 'Botosani', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2941, 'Braila', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2942, 'Brasov', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2943, 'Bucuresti', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2944, 'Buzau', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2945, 'Calarasi', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2946, 'Caras-Severin', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2947, 'Cluj', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2948, 'Constanta', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2949, 'Covasna', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2950, 'Dambovita', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2951, 'Dolj', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2952, 'Galati', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2953, 'Giurgiu', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2954, 'Gorj', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2955, 'Harghita', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2956, 'Hunedoara', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2957, 'Ialomita', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2958, 'Iasi', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2959, 'Ilfov', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2960, 'Maramures', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2961, 'Mehedinti', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2962, 'Mures', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2963, 'Neamt', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2964, 'Olt', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2965, 'Prahova', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2966, 'Salaj', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2967, 'Satu Mare', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2968, 'Sibiu', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2969, 'Sondelor', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2970, 'Suceava', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2971, 'Teleorman', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2972, 'Timis', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2973, 'Tulcea', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2974, 'Valcea', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2975, 'Vaslui', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2976, 'Vrancea', 180, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2977, 'Adygeja', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2978, 'Aga', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2979, 'Alanija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2980, 'Altaj', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2981, 'Amur', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2982, 'Arhangelsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2983, 'Astrahan', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2984, 'Bashkortostan', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2985, 'Belgorod', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2986, 'Brjansk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2987, 'Burjatija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2988, 'Chechenija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2989, 'Cheljabinsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2990, 'Chita', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2991, 'Chukotka', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2992, 'Chuvashija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2993, 'Dagestan', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2994, 'Evenkija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2995, 'Gorno-Altaj', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2996, 'Habarovsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2997, 'Hakasija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2998, 'Hanty-Mansija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(2999, 'Ingusetija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3000, 'Irkutsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3001, 'Ivanovo', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3002, 'Jamalo-Nenets', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3003, 'Jaroslavl', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3004, 'Jevrej', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3005, 'Kabardino-Balkarija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3006, 'Kaliningrad', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3007, 'Kalmykija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3008, 'Kaluga', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3009, 'Kamchatka', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3010, 'Karachaj-Cherkessija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3011, 'Karelija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3012, 'Kemerovo', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3013, 'Khabarovskiy Kray', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3014, 'Kirov', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3015, 'Komi', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3016, 'Komi-Permjakija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3017, 'Korjakija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3018, 'Kostroma', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3019, 'Krasnodar', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3020, 'Krasnojarsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3021, 'Krasnoyarskiy Kray', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3022, 'Kurgan', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3023, 'Kursk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3024, 'Leningrad', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3025, 'Lipeck', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3026, 'Magadan', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3027, 'Marij El', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3028, 'Mordovija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3029, 'Moscow', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3030, 'Moskovskaja Oblast', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3031, 'Moskovskaya Oblast', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3032, 'Moskva', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3033, 'Murmansk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3034, 'Nenets', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3035, 'Nizhnij Novgorod', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3036, 'Novgorod', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3037, 'Novokusnezk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3038, 'Novosibirsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3039, 'Omsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3040, 'Orenburg', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3041, 'Orjol', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3042, 'Penza', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3043, 'Perm', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3044, 'Primorje', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3045, 'Pskov', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3046, 'Pskovskaya Oblast', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3047, 'Rjazan', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3048, 'Rostov', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3049, 'Saha', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3050, 'Sahalin', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3051, 'Samara', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3052, 'Samarskaya', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3053, 'Sankt-Peterburg', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3054, 'Saratov', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3055, 'Smolensk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3056, 'Stavropol', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3057, 'Sverdlovsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3058, 'Tajmyrija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3059, 'Tambov', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3060, 'Tatarstan', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3061, 'Tjumen', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3062, 'Tomsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3063, 'Tula', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3064, 'Tver', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3065, 'Tyva', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3066, 'Udmurtija', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3067, 'Uljanovsk', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3068, 'Ulyanovskaya Oblast', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3069, 'Ust-Orda', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3070, 'Vladimir', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3071, 'Volgograd', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3072, 'Vologda', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3073, 'Voronezh', 181, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3074, 'Butare', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3075, 'Byumba', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3076, 'Cyangugu', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3077, 'Gikongoro', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3078, 'Gisenyi', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3079, 'Gitarama', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3080, 'Kibungo', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3081, 'Kibuye', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3082, 'Kigali-ngali', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3083, 'Ruhengeri', 182, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3084, 'Ascension', 183, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3085, 'Gough Island', 183, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3086, 'Saint Helena', 183, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3087, 'Tristan da Cunha', 183, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3088, 'Christ Church Nichola Town', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3089, 'Saint Anne Sandy Point', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3090, 'Saint George Basseterre', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3091, 'Saint George Gingerland', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3092, 'Saint James Windward', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3093, 'Saint John Capesterre', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3094, 'Saint John Figtree', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3095, 'Saint Mary Cayon', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3096, 'Saint Paul Capesterre', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3097, 'Saint Paul Charlestown', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3098, 'Saint Peter Basseterre', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3099, 'Saint Thomas Lowland', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3100, 'Saint Thomas Middle Island', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3101, 'Trinity Palmetto Point', 184, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3102, 'Anse-la-Raye', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3103, 'Canaries', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3104, 'Castries', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3105, 'Choiseul', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3106, 'Dennery', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3107, 'Gros Inlet', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3108, 'Laborie', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3109, 'Micoud', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3110, 'Soufriere', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3111, 'Vieux Fort', 185, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3112, 'Miquelon-Langlade', 186, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3113, 'Saint-Pierre', 186, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3114, 'Charlotte', 187, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3115, 'Grenadines', 187, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3116, 'Saint Andrew', 187, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3117, 'Saint David', 187, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3118, 'Saint George', 187, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3119, 'Saint Patrick', 187, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3120, 'A\'ana', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3121, 'Aiga-i-le-Tai', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3122, 'Atua', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3123, 'Fa\'asaleleaga', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3124, 'Gaga\'emauga', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3125, 'Gagaifomauga', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3126, 'Palauli', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3127, 'Satupa\'itea', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3128, 'Tuamasaga', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3129, 'Va\'a-o-Foi', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3130, 'Vaisigano', 188, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3131, 'Acquaviva', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3132, 'Borgo Maggiore', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3133, 'Chiesanuova', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3134, 'Domagnano', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3135, 'Faetano', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3136, 'Fiorentino', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3137, 'Montegiardino', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3138, 'San Marino', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3139, 'Serravalle', 189, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3140, 'Agua Grande', 190, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3141, 'Cantagalo', 190, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3142, 'Lemba', 190, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3143, 'Lobata', 190, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3144, 'Me-Zochi', 190, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3145, 'Pague', 190, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3146, 'Al Khobar', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3147, 'Aseer', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3148, 'Ash Sharqiyah', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3149, 'Asir', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3150, 'Central Province', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3151, 'Eastern Province', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3152, 'Ha\'il', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3153, 'Jawf', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3154, 'Jizan', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3155, 'Makkah', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3156, 'Najran', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3157, 'Qasim', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3158, 'Tabuk', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3159, 'Western Province', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3160, 'al-Bahah', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3161, 'al-Hudud-ash-Shamaliyah', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3162, 'al-Madinah', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3163, 'ar-Riyad', 191, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3164, 'Dakar', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3165, 'Diourbel', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3166, 'Fatick', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3167, 'Kaolack', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3168, 'Kolda', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3169, 'Louga', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3170, 'Saint-Louis', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3171, 'Tambacounda', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3172, 'Thies', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3173, 'Ziguinchor', 192, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3174, 'Central Serbia', 193, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3175, 'Kosovo and Metohija', 193, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3176, 'Vojvodina', 193, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3177, 'Anse Boileau', 194, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3178, 'Anse Royale', 194, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3179, 'Cascade', 194, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3180, 'Takamaka', 194, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3181, 'Victoria', 194, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3182, 'Eastern', 195, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3183, 'Northern', 195, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3184, 'Southern', 195, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3185, 'Western', 195, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3186, 'Singapore', 196, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3187, 'Banskobystricky', 197, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3188, 'Bratislavsky', 197, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3189, 'Kosicky', 197, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3190, 'Nitriansky', 197, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3191, 'Presovsky', 197, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3192, 'Trenciansky', 197, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3193, 'Trnavsky', 197, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3194, 'Zilinsky', 197, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3195, 'Benedikt', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3196, 'Gorenjska', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3197, 'Gorishka', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3198, 'Jugovzhodna Slovenija', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3199, 'Koroshka', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3200, 'ranjsko-krashka', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3201, 'Obalno-krashka', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3202, 'Obcina Domzale', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3203, 'Obcina Vitanje', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3204, 'Osrednjeslovenska', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3205, 'Podravska', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3206, 'Pomurska', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3207, 'Savinjska', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3208, 'Slovenian Littoral', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3209, 'Spodnjeposavska', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3210, 'Zasavska', 198, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3211, 'Pitcairn', 199, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3212, 'Central', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3213, 'Choiseul', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3214, 'Guadalcanal', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3215, 'Isabel', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3216, 'Makira and Ulawa', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3217, 'Malaita', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3218, 'Rennell and Bellona', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3219, 'Temotu', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3220, 'Western', 200, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3221, 'Awdal', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3222, 'Bakol', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3223, 'Banadir', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3224, 'Bari', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3225, 'Bay', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3226, 'Galgudug', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3227, 'Gedo', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3228, 'Hiran', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3229, 'Jubbada Hose', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3230, 'Jubbadha Dexe', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3231, 'Mudug', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3232, 'Nugal', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3233, 'Sanag', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3234, 'Shabellaha Dhexe', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3235, 'Shabellaha Hose', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3236, 'Togdher', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3237, 'Woqoyi Galbed', 201, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3238, 'Eastern Cape', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3239, 'Free State', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3240, 'Gauteng', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3241, 'Kempton Park', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3242, 'Kramerville', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3243, 'KwaZulu Natal', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3244, 'Limpopo', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3245, 'Mpumalanga', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3246, 'North West', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3247, 'Northern Cape', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3248, 'Parow', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3249, 'Table View', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3250, 'Umtentweni', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3251, 'Western Cape', 202, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3252, 'South Georgia', 203, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3253, 'Central Equatoria', 204, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3254, 'A Coruna', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3255, 'Alacant', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3256, 'Alava', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3257, 'Albacete', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3258, 'Almeria', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3260, 'Asturias', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3261, 'Avila', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3262, 'Badajoz', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3263, 'Balears', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3264, 'Barcelona', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3267, 'Burgos', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3268, 'Caceres', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3269, 'Cadiz', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3270, 'Cantabria', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0);
INSERT INTO `states` (`id`, `name`, `country_id`, `created_by`, `created_date`, `modified_by`, `modified_date`, `active`) VALUES
(3271, 'Castello', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3273, 'Ceuta', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3274, 'Ciudad Real', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3281, 'Cordoba', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3282, 'Cuenca', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3284, 'Girona', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3285, 'Granada', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3286, 'Guadalajara', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3287, 'Guipuzcoa', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3288, 'Huelva', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3289, 'Huesca', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3290, 'Jaen', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3291, 'La Rioja', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3292, 'Las Palmas', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3293, 'Leon', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3295, 'Lleida', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3296, 'Lugo', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3297, 'Madrid', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3298, 'Malaga', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3299, 'Melilla', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3300, 'Murcia', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3301, 'Navarra', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3302, 'Ourense', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3303, 'Pais Vasco', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3304, 'Palencia', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3305, 'Pontevedra', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3306, 'Salamanca', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3308, 'Segovia', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3309, 'Sevilla', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3310, 'Soria', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3311, 'Tarragona', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3312, 'Santa Cruz de Tenerife', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3313, 'Teruel', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3314, 'Toledo', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3315, 'Valencia', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3316, 'Valladolid', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3317, 'Vizcaya', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3318, 'Zamora', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3319, 'Zaragoza', 205, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3320, 'Amparai', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3321, 'Anuradhapuraya', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3322, 'Badulla', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3323, 'Boralesgamuwa', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3324, 'Colombo', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3325, 'Galla', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3326, 'Gampaha', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3327, 'Hambantota', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3328, 'Kalatura', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3329, 'Kegalla', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3330, 'Kilinochchi', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3331, 'Kurunegala', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3332, 'Madakalpuwa', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3333, 'Maha Nuwara', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3334, 'Malwana', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3335, 'Mannarama', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3336, 'Matale', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3337, 'Matara', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3338, 'Monaragala', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3339, 'Mullaitivu', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3340, 'North Eastern Province', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3341, 'North Western Province', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3342, 'Nuwara Eliya', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3343, 'Polonnaruwa', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3344, 'Puttalama', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3345, 'Ratnapuraya', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3346, 'Southern Province', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3347, 'Tirikunamalaya', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3348, 'Tuscany', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3349, 'Vavuniyawa', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3350, 'Western Province', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3351, 'Yapanaya', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3352, 'kadawatha', 206, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3353, 'A\'ali-an-Nil', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3354, 'Bahr-al-Jabal', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3355, 'Central Equatoria', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3356, 'Gharb Bahr-al-Ghazal', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3357, 'Gharb Darfur', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3358, 'Gharb Kurdufan', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3359, 'Gharb-al-Istiwa\'iyah', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3360, 'Janub Darfur', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3361, 'Janub Kurdufan', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3362, 'Junqali', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3363, 'Kassala', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3364, 'Nahr-an-Nil', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3365, 'Shamal Bahr-al-Ghazal', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3366, 'Shamal Darfur', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3367, 'Shamal Kurdufan', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3368, 'Sharq-al-Istiwa\'iyah', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3369, 'Sinnar', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3370, 'Warab', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3371, 'Wilayat al Khartum', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3372, 'al-Bahr-al-Ahmar', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3373, 'al-Buhayrat', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3374, 'al-Jazirah', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3375, 'al-Khartum', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3376, 'al-Qadarif', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3377, 'al-Wahdah', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3378, 'an-Nil-al-Abyad', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3379, 'an-Nil-al-Azraq', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3380, 'ash-Shamaliyah', 207, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3381, 'Brokopondo', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3382, 'Commewijne', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3383, 'Coronie', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3384, 'Marowijne', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3385, 'Nickerie', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3386, 'Para', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3387, 'Paramaribo', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3388, 'Saramacca', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3389, 'Wanica', 208, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3390, 'Svalbard', 209, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3391, 'Hhohho', 210, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3392, 'Lubombo', 210, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3393, 'Manzini', 210, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3394, 'Shiselweni', 210, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3395, 'Alvsborgs Lan', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3396, 'Angermanland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3397, 'Blekinge', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3398, 'Bohuslan', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3399, 'Dalarna', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3400, 'Gavleborg', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3401, 'Gaza', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3402, 'Gotland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3403, 'Halland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3404, 'Jamtland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3405, 'Jonkoping', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3406, 'Kalmar', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3407, 'Kristianstads', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3408, 'Kronoberg', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3409, 'Norrbotten', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3410, 'Orebro', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3411, 'Ostergotland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3412, 'Saltsjo-Boo', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3413, 'Skane', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3414, 'Smaland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3415, 'Sodermanland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3416, 'Stockholm', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3417, 'Uppsala', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3418, 'Varmland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3419, 'Vasterbotten', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3420, 'Vastergotland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3421, 'Vasternorrland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3422, 'Vastmanland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3423, 'Vastra Gotaland', 211, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3424, 'Aargau', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3425, 'Appenzell Inner-Rhoden', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3426, 'Appenzell-Ausser Rhoden', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3427, 'Basel-Landschaft', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3428, 'Basel-Stadt', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3429, 'Bern', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3430, 'Canton Ticino', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3431, 'Fribourg', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3432, 'Geneve', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3433, 'Glarus', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3434, 'Graubunden', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3435, 'Heerbrugg', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3436, 'Jura', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3437, 'Kanton Aargau', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3438, 'Luzern', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3439, 'Morbio Inferiore', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3440, 'Muhen', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3441, 'Neuchatel', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3442, 'Nidwalden', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3443, 'Obwalden', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3444, 'Sankt Gallen', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3445, 'Schaffhausen', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3446, 'Schwyz', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3447, 'Solothurn', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3448, 'Thurgau', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3449, 'Ticino', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3450, 'Uri', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3451, 'Valais', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3452, 'Vaud', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3453, 'Vauffelin', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3454, 'Zug', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3455, 'Zurich', 212, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3456, 'Aleppo', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3457, 'Dar\'a', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3458, 'Dayr-az-Zawr', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3459, 'Dimashq', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3460, 'Halab', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3461, 'Hamah', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3462, 'Hims', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3463, 'Idlib', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3464, 'Madinat Dimashq', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3465, 'Tartus', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3466, 'al-Hasakah', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3467, 'al-Ladhiqiyah', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3468, 'al-Qunaytirah', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3469, 'ar-Raqqah', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3470, 'as-Suwayda', 213, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3471, 'Changhua County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3472, 'Chiayi County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3473, 'Chiayi City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3474, 'Taipei City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3475, 'Hsinchu County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3476, 'Hsinchu City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3477, 'Hualien County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3480, 'Kaohsiung City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3481, 'Keelung City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3482, 'Kinmen County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3483, 'Miaoli County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3484, 'Nantou County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3486, 'Penghu County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3487, 'Pingtung County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3488, 'Taichung City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3492, 'Tainan City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3493, 'New Taipei City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3495, 'Taitung County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3496, 'Taoyuan City', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3497, 'Yilan County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3498, 'YunLin County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3500, 'Dushanbe', 215, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3501, 'Gorno-Badakhshan', 215, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3502, 'Karotegin', 215, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3503, 'Khatlon', 215, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3504, 'Sughd', 215, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3505, 'Arusha', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3506, 'Dar es Salaam', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3507, 'Dodoma', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3508, 'Iringa', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3509, 'Kagera', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3510, 'Kigoma', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3511, 'Kilimanjaro', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3512, 'Lindi', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3513, 'Mara', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3514, 'Mbeya', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3515, 'Morogoro', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3516, 'Mtwara', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3517, 'Mwanza', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3518, 'Pwani', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3519, 'Rukwa', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3520, 'Ruvuma', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3521, 'Shinyanga', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3522, 'Singida', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3523, 'Tabora', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3524, 'Tanga', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3525, 'Zanzibar and Pemba', 216, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3526, 'Amnat Charoen', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3527, 'Ang Thong', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3528, 'Bangkok', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3529, 'Buri Ram', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3530, 'Chachoengsao', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3531, 'Chai Nat', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3532, 'Chaiyaphum', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3533, 'Changwat Chaiyaphum', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3534, 'Chanthaburi', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3535, 'Chiang Mai', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3536, 'Chiang Rai', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3537, 'Chon Buri', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3538, 'Chumphon', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3539, 'Kalasin', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3540, 'Kamphaeng Phet', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3541, 'Kanchanaburi', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3542, 'Khon Kaen', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3543, 'Krabi', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3544, 'Krung Thep', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3545, 'Lampang', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3546, 'Lamphun', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3547, 'Loei', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3548, 'Lop Buri', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3549, 'Mae Hong Son', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3550, 'Maha Sarakham', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3551, 'Mukdahan', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3552, 'Nakhon Nayok', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3553, 'Nakhon Pathom', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3554, 'Nakhon Phanom', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3555, 'Nakhon Ratchasima', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3556, 'Nakhon Sawan', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3557, 'Nakhon Si Thammarat', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3558, 'Nan', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3559, 'Narathiwat', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3560, 'Nong Bua Lam Phu', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3561, 'Nong Khai', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3562, 'Nonthaburi', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3563, 'Pathum Thani', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3564, 'Pattani', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3565, 'Phangnga', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3566, 'Phatthalung', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3567, 'Phayao', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3568, 'Phetchabun', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3569, 'Phetchaburi', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3570, 'Phichit', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3571, 'Phitsanulok', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3572, 'Phra Nakhon Si Ayutthaya', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3573, 'Phrae', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3574, 'Phuket', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3575, 'Prachin Buri', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3576, 'Prachuap Khiri Khan', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3577, 'Ranong', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3578, 'Ratchaburi', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3579, 'Rayong', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3580, 'Roi Et', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3581, 'Sa Kaeo', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3582, 'Sakon Nakhon', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3583, 'Samut Prakan', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3584, 'Samut Sakhon', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3585, 'Samut Songkhran', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3586, 'Saraburi', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3587, 'Satun', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3588, 'Si Sa Ket', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3589, 'Sing Buri', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3590, 'Songkhla', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3591, 'Sukhothai', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3592, 'Suphan Buri', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3593, 'Surat Thani', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3594, 'Surin', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3595, 'Tak', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3596, 'Trang', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3597, 'Trat', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3598, 'Ubon Ratchathani', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3599, 'Udon Thani', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3600, 'Uthai Thani', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3601, 'Uttaradit', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3602, 'Yala', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3603, 'Yasothon', 217, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3604, 'Centre', 218, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3605, 'Kara', 218, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3606, 'Maritime', 218, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3607, 'Plateaux', 218, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3608, 'Savanes', 218, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3609, 'Atafu', 219, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3610, 'Fakaofo', 219, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3611, 'Nukunonu', 219, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3612, 'Eua', 220, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3613, 'Ha\'apai', 220, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3614, 'Niuas', 220, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3615, 'Tongatapu', 220, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3616, 'Vava\'u', 220, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3617, 'Arima-Tunapuna-Piarco', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3618, 'Caroni', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3619, 'Chaguanas', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3620, 'Couva-Tabaquite-Talparo', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3621, 'Diego Martin', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3622, 'Glencoe', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3623, 'Penal Debe', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3624, 'Point Fortin', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3625, 'Port of Spain', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3626, 'Princes Town', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3627, 'Saint George', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3628, 'San Fernando', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3629, 'San Juan', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3630, 'Sangre Grande', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3631, 'Siparia', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3632, 'Tobago', 221, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3633, 'Aryanah', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3634, 'Bajah', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3635, 'Bin \'Arus', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3636, 'Binzart', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3637, 'Gouvernorat de Ariana', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3638, 'Gouvernorat de Nabeul', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3639, 'Gouvernorat de Sousse', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3640, 'Hammamet Yasmine', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3641, 'Jundubah', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3642, 'Madaniyin', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3643, 'Manubah', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3644, 'Monastir', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3645, 'Nabul', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3646, 'Qabis', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3647, 'Qafsah', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3648, 'Qibili', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3649, 'Safaqis', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3650, 'Sfax', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3651, 'Sidi Bu Zayd', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3652, 'Silyanah', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3653, 'Susah', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3654, 'Tatawin', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3655, 'Tawzar', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3656, 'Tunis', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3657, 'Zaghwan', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3658, 'al-Kaf', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3659, 'al-Mahdiyah', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3660, 'al-Munastir', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3661, 'al-Qasrayn', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3662, 'al-Qayrawan', 222, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3663, 'Adana', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3664, 'Adiyaman', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3665, 'Afyon', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3666, 'Agri', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3667, 'Aksaray', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3668, 'Amasya', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3669, 'Ankara', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3670, 'Antalya', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3671, 'Ardahan', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3672, 'Artvin', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3673, 'Aydin', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3674, 'Balikesir', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3675, 'Bartin', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3676, 'Batman', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3677, 'Bayburt', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3678, 'Bilecik', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3679, 'Bingol', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3680, 'Bitlis', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3681, 'Bolu', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3682, 'Burdur', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3683, 'Bursa', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3684, 'Canakkale', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3685, 'Cankiri', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3686, 'Corum', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3687, 'Denizli', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3688, 'Diyarbakir', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3689, 'Duzce', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3690, 'Edirne', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3691, 'Elazig', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3692, 'Erzincan', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3693, 'Erzurum', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3694, 'Eskisehir', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3695, 'Gaziantep', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3696, 'Giresun', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3697, 'Gumushane', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3698, 'Hakkari', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3699, 'Hatay', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3700, 'Icel', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3701, 'Igdir', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3702, 'Isparta', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3703, 'Istanbul', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3704, 'Izmir', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3705, 'Kahramanmaras', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3706, 'Karabuk', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3707, 'Karaman', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3708, 'Kars', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3709, 'Karsiyaka', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3710, 'Kastamonu', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3711, 'Kayseri', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3712, 'Kilis', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3713, 'Kirikkale', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3714, 'Kirklareli', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3715, 'Kirsehir', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3716, 'Kocaeli', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3717, 'Konya', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3718, 'Kutahya', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3719, 'Lefkosa', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3720, 'Malatya', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3721, 'Manisa', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3722, 'Mardin', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3723, 'Mugla', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3724, 'Mus', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3725, 'Nevsehir', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3726, 'Nigde', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3727, 'Ordu', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3728, 'Osmaniye', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3729, 'Rize', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3730, 'Sakarya', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3731, 'Samsun', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3732, 'Sanliurfa', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3733, 'Siirt', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3734, 'Sinop', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3735, 'Sirnak', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3736, 'Sivas', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3737, 'Tekirdag', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3738, 'Tokat', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3739, 'Trabzon', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3740, 'Tunceli', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3741, 'Usak', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3742, 'Van', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3743, 'Yalova', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3744, 'Yozgat', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3745, 'Zonguldak', 223, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3746, 'Ahal', 224, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3747, 'Asgabat', 224, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3748, 'Balkan', 224, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3749, 'Dasoguz', 224, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3750, 'Lebap', 224, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3751, 'Mari', 224, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3752, 'Grand Turk', 225, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3753, 'South Caicos and East Caicos', 225, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3754, 'Funafuti', 226, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3755, 'Nanumanga', 226, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3756, 'Nanumea', 226, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3757, 'Niutao', 226, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3758, 'Nui', 226, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3759, 'Nukufetau', 226, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3760, 'Nukulaelae', 226, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3761, 'Vaitupu', 226, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3762, 'Central', 227, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3763, 'Eastern', 227, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3764, 'Northern', 227, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3765, 'Western', 227, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3766, 'Cherkas\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3767, 'Chernihivs\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3768, 'Chernivets\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3769, 'Crimea', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3770, 'Dnipropetrovska', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3771, 'Donets\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3772, 'Ivano-Frankivs\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3773, 'Kharkiv', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3774, 'Kharkov', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3775, 'Khersonska', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3776, 'Khmel\'nyts\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3777, 'Kirovohrad', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3778, 'Krym', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3779, 'Kyyiv', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3780, 'Kyyivs\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3781, 'L\'vivs\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3782, 'Luhans\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3783, 'Mykolayivs\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3784, 'Odes\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3785, 'Odessa', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3786, 'Poltavs\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3787, 'Rivnens\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3788, 'Sevastopol\'', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3789, 'Sums\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3790, 'Ternopil\'s\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3791, 'Volyns\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3792, 'Vynnyts\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3793, 'Zakarpats\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3794, 'Zaporizhia', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3795, 'Zhytomyrs\'ka', 228, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3796, 'Abu Zabi', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3797, 'Ajman', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3798, 'Dubai', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3799, 'Ras al-Khaymah', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3800, 'Sharjah', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3801, 'Sharjha', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3802, 'Umm al Qaywayn', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3803, 'al-Fujayrah', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3804, 'ash-Shariqah', 229, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3805, 'Aberdeen', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3806, 'Aberdeenshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3807, 'Argyll', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3808, 'Armagh', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3809, 'Bedfordshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3810, 'Belfast', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3811, 'Berkshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3812, 'Birmingham', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3813, 'Brechin', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3814, 'Bridgnorth', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3815, 'Bristol', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3816, 'Buckinghamshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3817, 'Cambridge', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3818, 'Cambridgeshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3819, 'Channel Islands', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3820, 'Cheshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3821, 'Cleveland', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3822, 'Co Fermanagh', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3823, 'Conwy', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3824, 'Cornwall', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3825, 'Coventry', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3826, 'Craven Arms', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3827, 'Cumbria', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3828, 'Denbighshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3829, 'Derby', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3830, 'Derbyshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3831, 'Devon', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3832, 'Dial Code Dungannon', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3833, 'Didcot', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3834, 'Dorset', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3835, 'Dunbartonshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3836, 'Durham', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3837, 'East Dunbartonshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3838, 'East Lothian', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3839, 'East Midlands', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3840, 'East Sussex', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3841, 'East Yorkshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3842, 'England', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3843, 'Essex', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3844, 'Fermanagh', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3845, 'Fife', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3846, 'Flintshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3847, 'Fulham', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3848, 'Gainsborough', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3849, 'Glocestershire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3850, 'Gwent', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3851, 'Hampshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3852, 'Hants', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3853, 'Herefordshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3854, 'Hertfordshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3855, 'Ireland', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3856, 'Isle Of Man', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3857, 'Isle of Wight', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3858, 'Kenford', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3859, 'Kent', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3860, 'Kilmarnock', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3861, 'Lanarkshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3862, 'Lancashire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3863, 'Leicestershire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3864, 'Lincolnshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3865, 'Llanymynech', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3866, 'London', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3867, 'Ludlow', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3868, 'Manchester', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3869, 'Mayfair', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3870, 'Merseyside', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3871, 'Mid Glamorgan', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3872, 'Middlesex', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3873, 'Mildenhall', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3874, 'Monmouthshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3875, 'Newton Stewart', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3876, 'Norfolk', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3877, 'North Humberside', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3878, 'North Yorkshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3879, 'Northamptonshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3880, 'Northants', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3881, 'Northern Ireland', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3882, 'Northumberland', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3883, 'tinghamshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3884, 'Oxford', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3885, 'Powys', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3886, 'Roos-shire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3887, 'SUSSEX', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3888, 'Sark', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3889, 'Scotland', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3890, 'Scottish Borders', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3891, 'Shropshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3892, 'Somerset', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3893, 'South Glamorgan', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3894, 'South Wales', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3895, 'South Yorkshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3896, 'Southwell', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3897, 'Staffordshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3898, 'Strabane', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3899, 'Suffolk', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3900, 'Surrey', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3901, 'Sussex', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3902, 'Twickenham', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3903, 'Tyne and Wear', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3904, 'Tyrone', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3905, 'Utah', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3906, 'Wales', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3907, 'Warwickshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3908, 'West Lothian', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3909, 'West Midlands', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3910, 'West Sussex', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3911, 'West Yorkshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3912, 'Whissendine', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3913, 'Wiltshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3914, 'Wokingham', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3915, 'Worcestershire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3916, 'Wrexham', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3917, 'Wurttemberg', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3918, 'Yorkshire', 230, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3919, 'Alabama', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3920, 'Alaska', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3921, 'Arizona', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3922, 'Arkansas', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3923, 'Byram', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3924, 'California', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3925, 'Cokato', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3926, 'Colorado', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3927, 'Connecticut', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3928, 'Delaware', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3929, 'District of Columbia', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3930, 'Florida', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3931, 'Georgia', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3932, 'Hawaii', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3933, 'Idaho', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3934, 'Illinois', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3935, 'Indiana', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3936, 'Iowa', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3937, 'Kansas', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3938, 'Kentucky', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3939, 'Louisiana', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3940, 'Lowa', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3941, 'Maine', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3942, 'Maryland', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3943, 'Massachusetts', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3944, 'Medfield', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3945, 'Michigan', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3946, 'Minnesota', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3947, 'Mississippi', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3948, 'Missouri', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3949, 'Montana', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3950, 'Nebraska', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3951, 'Nevada', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3952, 'New Hampshire', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3953, 'New Jersey', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3954, 'New Jersy', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3955, 'New Mexico', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3956, 'New York', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3957, 'North Carolina', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3958, 'North Dakota', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3959, 'Ohio', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3960, 'Oklahoma', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3961, 'Ontario', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3962, 'Oregon', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3963, 'Pennsylvania', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3964, 'Ramey', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3965, 'Rhode Island', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3966, 'South Carolina', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3967, 'South Dakota', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3968, 'Sublimity', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3969, 'Tennessee', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3970, 'Texas', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3971, 'Trimble', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3972, 'Utah', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3973, 'Vermont', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3974, 'Virginia', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3975, 'Washington', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3976, 'West Virginia', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3977, 'Wisconsin', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3978, 'Wyoming', 231, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3979, 'United States Minor Outlying I', 232, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3980, 'Artigas', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3981, 'Canelones', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3982, 'Cerro Largo', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3983, 'Colonia', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3984, 'Durazno', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3985, 'FLorida', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3986, 'Flores', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3987, 'Lavalleja', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3988, 'Maldonado', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3989, 'Montevideo', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3990, 'Paysandu', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3991, 'Rio Negro', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3992, 'Rivera', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3993, 'Rocha', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3994, 'Salto', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3995, 'San Jose', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3996, 'Soriano', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3997, 'Tacuarembo', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3998, 'Treinta y Tres', 233, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(3999, 'Andijon', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4000, 'Buhoro', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4001, 'Buxoro Viloyati', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4002, 'Cizah', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4003, 'Fargona', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4004, 'Horazm', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4005, 'Kaskadar', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4006, 'Korakalpogiston', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4007, 'Namangan', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4008, 'Navoi', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4009, 'Samarkand', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4010, 'Sirdare', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4011, 'Surhondar', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4012, 'Toskent', 234, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4013, 'Malampa', 235, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4014, 'Penama', 235, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4015, 'Sanma', 235, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4016, 'Shefa', 235, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4017, 'Tafea', 235, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4018, 'Torba', 235, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4019, 'Vatican City State (Holy See)', 236, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4020, 'Amazonas', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4021, 'Anzoategui', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4022, 'Apure', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4023, 'Aragua', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4024, 'Barinas', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4025, 'Bolivar', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4026, 'Carabobo', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4027, 'Cojedes', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4028, 'Delta Amacuro', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4029, 'Distrito Federal', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4030, 'Falcon', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4031, 'Guarico', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4032, 'Lara', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4033, 'Merida', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4034, 'Miranda', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4035, 'Monagas', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4036, 'Nueva Esparta', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4037, 'Portuguesa', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4038, 'Sucre', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4039, 'Tachira', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4040, 'Trujillo', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4041, 'Vargas', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4042, 'Yaracuy', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4043, 'Zulia', 237, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4044, 'Bac Giang', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4045, 'Binh Dinh', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4046, 'Binh Duong', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4047, 'Da Nang', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4048, 'Dong Bang Song Cuu Long', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4049, 'Dong Bang Song Hong', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4050, 'Dong Nai', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4051, 'Dong Nam Bo', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4052, 'Duyen Hai Mien Trung', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4053, 'Hanoi', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4054, 'Hung Yen', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4055, 'Khu Bon Cu', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4056, 'Long An', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4057, 'Mien Nui Va Trung Du', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4058, 'Thai Nguyen', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4059, 'Thanh Pho Ho Chi Minh', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4060, 'Thu Do Ha Noi', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4061, 'Tinh Can Tho', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4062, 'Tinh Da Nang', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4063, 'Tinh Gia Lai', 238, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4064, 'Anegada', 239, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4065, 'Jost van Dyke', 239, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4066, 'Tortola', 239, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4067, 'Saint Croix', 240, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4068, 'Saint John', 240, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4069, 'Saint Thomas', 240, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4070, 'Alo', 241, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4071, 'Singave', 241, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4072, 'Wallis', 241, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4073, 'Bu Jaydur', 242, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4074, 'Wad-adh-Dhahab', 242, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4075, 'al-\'Ayun', 242, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4076, 'as-Samarah', 242, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4077, '\'Adan', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4078, 'Abyan', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4079, 'Dhamar', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4080, 'Hadramaut', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4081, 'Hajjah', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4082, 'Hudaydah', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4083, 'Ibb', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4084, 'Lahij', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4085, 'Ma\'rib', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4086, 'Madinat San\'a', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4087, 'Sa\'dah', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4088, 'Sana', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4089, 'Shabwah', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4090, 'Ta\'izz', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0);
INSERT INTO `states` (`id`, `name`, `country_id`, `created_by`, `created_date`, `modified_by`, `modified_date`, `active`) VALUES
(4091, 'al-Bayda', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4092, 'al-Hudaydah', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4093, 'al-Jawf', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4094, 'al-Mahrah', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4095, 'al-Mahwit', 243, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4096, 'Central Serbia', 244, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4097, 'Kosovo and Metohija', 244, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4098, 'Montenegro', 244, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4099, 'Republic of Serbia', 244, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4100, 'Serbia', 244, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4101, 'Vojvodina', 244, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4102, 'Central', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4103, 'Copperbelt', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4104, 'Eastern', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4105, 'Luapala', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4106, 'Lusaka', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4107, 'North-Western', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4108, 'Northern', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4109, 'Southern', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4110, 'Western', 245, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4111, 'Bulawayo', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4112, 'Harare', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4113, 'Manicaland', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4114, 'Mashonaland Central', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4115, 'Mashonaland East', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4116, 'Mashonaland West', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4117, 'Masvingo', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4118, 'Matabeleland North', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4119, 'Matabeleland South', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4120, 'Midlands', 246, 0, '2019-04-26 07:22:56', 0, NULL, 0),
(4121, 'Lienchiang County', 214, 0, '2019-04-26 07:22:56', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` int(11)  NULL,
  `name` varchar(255)  NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `kmlfile` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `posid` int(11) DEFAULT NULL,
  `active` tinyint(1)  NULL,
  `locality` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `store_channel_mapping`
--

CREATE TABLE `store_channel_mapping` (
  `id` int(11)  NULL,
  `store_id` int(11)  NULL,
  `channel_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modifeid_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `store_payment_option`
--

CREATE TABLE `store_payment_option` (
  `id` int(11)  NULL,
  `store_id` int(11)  NULL,
  `payment_option_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `store_saleitems_mapping`
--

CREATE TABLE `store_saleitems_mapping` (
  `id` int(11)  NULL,
  `manageprice_id` int(11)  NULL,
  `store_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11)  NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` int(11)  NULL,
  `template_name` varchar(255)  NULL,
  `template_body` text  NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `translations`
--

CREATE TABLE `translations` (
  `id` int(11)  NULL,
  `type` int(11)  NULL,
  `type_id` int(11)  NULL,
  `lang_id` int(11)  NULL,
  `value` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `type_tables`
--

CREATE TABLE `type_tables` (
  `id` int(11)  NULL,
  `type` varchar(255)  NULL,
  `active` tinyint(1) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11)  NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255)  NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11)  NULL,
  `user_id` int(11)  NULL,
  `role_id` int(11)  NULL,
  `created_by` int(11)  NULL,
  `created_date` timestamp  NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11)  NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` int(11)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `website_users`
--

CREATE TABLE `website_users` (
  `id` int(11)  NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255)  NULL,
  `phone` varchar(255)  NULL,
  `address` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_types`
--
ALTER TABLE `access_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_size_mapping`
--
ALTER TABLE `category_size_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `channels`
--
ALTER TABLE `channels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country_location_type_mapping`
--
ALTER TABLE `country_location_type_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country_location_type_mapping_ibfk_1` (`country_id`),
  ADD KEY `country_location_type_mapping_ibfk_2` (`location_type_id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealitem_saleitem_mapping`
--
ALTER TABLE `dealitem_saleitem_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dealitem_id` (`dealitem_id`);

--
-- Indexes for table `deals`
--
ALTER TABLE `deals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deal_category_mapping`
--
ALTER TABLE `deal_category_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deal_id` (`deal_id`);

--
-- Indexes for table `deal_items`
--
ALTER TABLE `deal_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deal_id` (`deal_id`);

--
-- Indexes for table `deal_modifiergroup_mapping`
--
ALTER TABLE `deal_modifiergroup_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deal_id` (`deal_id`);


--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location_types`
--
ALTER TABLE `location_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mail_server_details`
--
ALTER TABLE `mail_server_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manage_price`
--
ALTER TABLE `manage_price`
  ADD PRIMARY KEY (`id`),
  ADD KEY `manage_price_ibfk_1` (`saleitem_id`);

--
-- Indexes for table `modifiers`
--
ALTER TABLE `modifiers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modifiergroup_id` (`modifiergroup_id`);

--
-- Indexes for table `modifier_category_mapping`
--
ALTER TABLE `modifier_category_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `modifier_groups`
--
ALTER TABLE `modifier_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `operating_timings`
--
ALTER TABLE `operating_timings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_ibfk1` (`country`),
  ADD KEY `order_ibfk2` (`state`);

--
-- Indexes for table `order_deliveries`
--
ALTER TABLE `order_deliveries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_delivery_1` (`order_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items` (`order_id`),
  ADD KEY `order_items_ibfk_1` (`saleitem_id`);

--
-- Indexes for table `order_modifiers`
--
ALTER TABLE `order_modifiers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_modifiers_ibfk_1` (`order_item_id`),
  ADD KEY `order_modifiers_ibfk_2` (`modifier_id`),
  ADD KEY `order_modifiers_ibfk_3` (`modifiergroup_id`);

--
-- Indexes for table `order_suppliers`
--
ALTER TABLE `order_suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_options`
--
ALTER TABLE `payment_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_modules`
--
ALTER TABLE `role_modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `saleitem_channel_mapping`
--
ALTER TABLE `saleitem_channel_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `saleitem_channel_mapping_ibfk_1` (`manageprice_id`);

--
-- Indexes for table `saleitem_day_mapping`
--
ALTER TABLE `saleitem_day_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `saleitem_day_mapping_ibfk_1` (`manageprice_id`);

--
-- Indexes for table `saleitem_modifiergroup_mapping`
--
ALTER TABLE `saleitem_modifiergroup_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `saleitem_id` (`saleitem_id`);

--
-- Indexes for table `saleitem_modifier_mapping`
--
ALTER TABLE `saleitem_modifier_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `saleitemmodifiergroup_id` (`saleitem_modifiergroup_id`);

--
-- Indexes for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `setting_types`
--
ALTER TABLE `setting_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_settings`
--
ALTER TABLE `sms_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store_channel_mapping`
--
ALTER TABLE `store_channel_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `store_payment_option`
--
ALTER TABLE `store_payment_option`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mapping` (`store_id`,`payment_option_id`);

--
-- Indexes for table `store_saleitems_mapping`
--
ALTER TABLE `store_saleitems_mapping`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `manageprice_id` (`manageprice_id`,`store_id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `suppliers_ibfk_1` (`state`),
  ADD KEY `suppliers_ibfk_2` (`country`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type_tables`
--
ALTER TABLE `type_tables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `website_users`
--
ALTER TABLE `website_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access_types`
--
ALTER TABLE `access_types`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category_size_mapping`
--
ALTER TABLE `category_size_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `channels`
--
ALTER TABLE `channels`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `country_location_type_mapping`
--
ALTER TABLE `country_location_type_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealitem_saleitem_mapping`
--
ALTER TABLE `dealitem_saleitem_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deals`
--
ALTER TABLE `deals`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deal_category_mapping`
--
ALTER TABLE `deal_category_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deal_items`
--
ALTER TABLE `deal_items`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deal_modifiergroup_mapping`
--
ALTER TABLE `deal_modifiergroup_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;


--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `location_types`
--
ALTER TABLE `location_types`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mail_server_details`
--
ALTER TABLE `mail_server_details`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manage_price`
--
ALTER TABLE `manage_price`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modifiers`
--
ALTER TABLE `modifiers`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modifier_category_mapping`
--
ALTER TABLE `modifier_category_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modifier_groups`
--
ALTER TABLE `modifier_groups`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `operating_timings`
--
ALTER TABLE `operating_timings`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_deliveries`
--
ALTER TABLE `order_deliveries`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_modifiers`
--
ALTER TABLE `order_modifiers`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_suppliers`
--
ALTER TABLE `order_suppliers`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_options`
--
ALTER TABLE `payment_options`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role_modules`
--
ALTER TABLE `role_modules`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saleitem_channel_mapping`
--
ALTER TABLE `saleitem_channel_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saleitem_day_mapping`
--
ALTER TABLE `saleitem_day_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saleitem_modifiergroup_mapping`
--
ALTER TABLE `saleitem_modifiergroup_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saleitem_modifier_mapping`
--
ALTER TABLE `saleitem_modifier_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sale_items`
--
ALTER TABLE `sale_items`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setting_types`
--
ALTER TABLE `setting_types`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sms_settings`
--
ALTER TABLE `sms_settings`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `store_channel_mapping`
--
ALTER TABLE `store_channel_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `store_payment_option`
--
ALTER TABLE `store_payment_option`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `store_saleitems_mapping`
--
ALTER TABLE `store_saleitems_mapping`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `type_tables`
--
ALTER TABLE `type_tables`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `website_users`
--
ALTER TABLE `website_users`
  MODIFY `id` int(11)  NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category_size_mapping`
--
ALTER TABLE `category_size_mapping`
  ADD CONSTRAINT `category_size_mapping_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `country_location_type_mapping`
--
ALTER TABLE `country_location_type_mapping`
  ADD CONSTRAINT `country_location_type_mapping_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `country_location_type_mapping_ibfk_2` FOREIGN KEY (`location_type_id`) REFERENCES `location_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dealitem_saleitem_mapping`
--
ALTER TABLE `dealitem_saleitem_mapping`
  ADD CONSTRAINT `dealitem_saleitem_mapping_ibfk_2` FOREIGN KEY (`dealitem_id`) REFERENCES `deal_items` (`id`);

--
-- Constraints for table `deal_category_mapping`
--
ALTER TABLE `deal_category_mapping`
  ADD CONSTRAINT `deal_category_mapping_ibfk_1` FOREIGN KEY (`deal_id`) REFERENCES `deals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `deal_items`
--
ALTER TABLE `deal_items`
  ADD CONSTRAINT `deal_items_ibfk_1` FOREIGN KEY (`deal_id`) REFERENCES `deals` (`id`);

--
-- Constraints for table `deal_modifiergroup_mapping`
--
ALTER TABLE `deal_modifiergroup_mapping`
  ADD CONSTRAINT `deal_modifiergroup_mapping_ibfk_1` FOREIGN KEY (`deal_id`) REFERENCES `deals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `franchises`
--
ALTER TABLE `franchises`
  ADD CONSTRAINT `franchises_ibfk_1` FOREIGN KEY (`state`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `franchises_ibfk_2` FOREIGN KEY (`country`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `manage_price`
--
ALTER TABLE `manage_price`
  ADD CONSTRAINT `manage_price_ibfk_1` FOREIGN KEY (`saleitem_id`) REFERENCES `sale_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `modifiers`
--
ALTER TABLE `modifiers`
  ADD CONSTRAINT `modifiers_ibfk_1` FOREIGN KEY (`modifiergroup_id`) REFERENCES `modifier_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `modifier_category_mapping`
--
ALTER TABLE `modifier_category_mapping`
  ADD CONSTRAINT `modifier_category_mapping_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `operating_timings`
--
ALTER TABLE `operating_timings`
  ADD CONSTRAINT `operating_timings_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `order_ibfk1` FOREIGN KEY (`country`) REFERENCES `countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `order_ibfk2` FOREIGN KEY (`state`) REFERENCES `states` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `order_deliveries`
--
ALTER TABLE `order_deliveries`
  ADD CONSTRAINT `order_delivery_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`saleitem_id`) REFERENCES `sale_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_modifiers`
--
ALTER TABLE `order_modifiers`
  ADD CONSTRAINT `order_modifiers_ibfk_1` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_modifiers_ibfk_2` FOREIGN KEY (`modifier_id`) REFERENCES `modifiers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_modifiers_ibfk_3` FOREIGN KEY (`modifiergroup_id`) REFERENCES `modifier_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_modules`
--
ALTER TABLE `role_modules`
  ADD CONSTRAINT `role_modules_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `saleitem_channel_mapping`
--
ALTER TABLE `saleitem_channel_mapping`
  ADD CONSTRAINT `saleitem_channel_mapping_ibfk_1` FOREIGN KEY (`manageprice_id`) REFERENCES `manage_price` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `saleitem_day_mapping`
--
ALTER TABLE `saleitem_day_mapping`
  ADD CONSTRAINT `saleitem_day_mapping_ibfk_1` FOREIGN KEY (`manageprice_id`) REFERENCES `manage_price` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `saleitem_modifiergroup_mapping`
--
ALTER TABLE `saleitem_modifiergroup_mapping`
  ADD CONSTRAINT `saleitem_modifiergroup_mapping_ibfk_1` FOREIGN KEY (`saleitem_id`) REFERENCES `sale_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `saleitem_modifier_mapping`
--
ALTER TABLE `saleitem_modifier_mapping`
  ADD CONSTRAINT `saleitem_modifier_mapping_ibfk_1` FOREIGN KEY (`saleitem_modifiergroup_id`) REFERENCES `saleitem_modifiergroup_mapping` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stores`
--
ALTER TABLE `stores`
  ADD CONSTRAINT `stores_ibfk_1` FOREIGN KEY (`franchise_id`) REFERENCES `franchises` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `store_channel_mapping`
--
ALTER TABLE `store_channel_mapping`
  ADD CONSTRAINT `store_channel_mapping_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `store_payment_option`
--
ALTER TABLE `store_payment_option`
  ADD CONSTRAINT `store_payment_option_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `store_saleitems_mapping`
--
ALTER TABLE `store_saleitems_mapping`
  ADD CONSTRAINT `store_saleitems_mapping_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `store_saleitems_mapping_ibfk_2` FOREIGN KEY (`manageprice_id`) REFERENCES `manage_price` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD CONSTRAINT `suppliers_ibfk_1` FOREIGN KEY (`state`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `suppliers_ibfk_2` FOREIGN KEY (`country`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_role`
--
ALTER TABLE `user_role`
  ADD CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
